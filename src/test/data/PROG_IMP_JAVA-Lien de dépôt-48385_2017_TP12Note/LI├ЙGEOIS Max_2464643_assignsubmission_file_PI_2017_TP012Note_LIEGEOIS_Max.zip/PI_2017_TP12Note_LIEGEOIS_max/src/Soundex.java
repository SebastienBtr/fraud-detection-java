
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if ((c=='B')||(c==('P'))) {
			return '1';
		}
		else if ((c=='C'||(c=='K')||(c=='Q'))) {
			return '2';
		}
		else if ((c=='D')||(c=='T')) {
			return '3';
		}
		else if ((c=='L')) {
			return '4';
		}
		else if((c=='M')||(c=='N')) {
			return '5';
		}
		else if (c=='R') {
			return '6';
		}
		else if((c=='G')||(c=='J')) {
			return '7';
		}
		else if((c=='S')||(c=='X')||(c==('Z'))) {
			return '8';
		}
		else if ((c=='F'||(c=='V'))) {
			return '9';
		}
		return '0';
		}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String c="";
		String c1="";
		c=""+s.charAt(0);
		int j=1;
		while (j<5) {
			if (Soundex.coderCaractere(s.charAt(j))=='0') {
				j=j+1;
			}
			else if (Soundex.coderCaractere(s.charAt(j))==Soundex.coderCaractere(s.charAt(j-1))) {
				j=j+1;
			}
			else {
				c=c+Soundex.coderCaractere(s.charAt(j));
				j=j+1;
			}
			c1=c;
		}
		if ((c1.length()<4)) {
		for (int i=0;i<4-c1.length();i++) {
			c1=c1+" ";
		}
		}
		return c1;
	}
}
