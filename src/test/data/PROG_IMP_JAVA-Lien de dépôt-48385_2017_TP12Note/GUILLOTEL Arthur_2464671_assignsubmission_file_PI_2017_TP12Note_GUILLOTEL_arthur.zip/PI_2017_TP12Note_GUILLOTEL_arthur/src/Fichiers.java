import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	/** public static boolean contient(String nomFichier, String mot) {
		String ligne;
		boolean trouve=false;
		try {
			BufferedReader aLire = new BufferedReader(
			new FileReader("nomFichier"));// ouverture du fichier
			do {
				ligne = aLire.readLine();
				if (ligne!=null) {
					int ll=ligne.length();
					int lm=mot.length();
					int k=0;
					while (!trouve && k<=(ll-lm)) {
						int j=0;
						while (ligne.charAt(k+j)==mot.charAt(j) && j<lm) {
							j++;
						}
						trouve=(j==lm);
						k++;
					}
				}
			} while (ligne!=null);
			aLire.close();// On ferme le fichier
		} catch (IOException e) {
		System.out.println("Exception "+e+" levee");
		}
		return trouve;
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		if (File.isFile()) {
			return 
		}
	}


}
