
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char code='0';
		if (c=='B'||c=='P') {
			code='1';
		}
		else if (c=='C'||c=='K'||c=='Q') {
			code='2';
		}
		else if (c=='D'||c=='T') {
			code='3';
		}
		else if (c=='L') {
			code='4';
		}
		else if (c=='M'||c=='N') {
			code='5';
		}
		else if (c=='R') {
			code='6';
		}
		else if (c=='G'||c=='J') {
			code='7';
		}
		else if (c=='S'||c=='X'||c=='Z') {
			code='8';
		}
		else if (c=='F'||c=='V') {
			code='9';
		}
		return code;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code="";
		code+=s.charAt(0);
		int i=1;
		char test='0';
		while ((i<s.length())&&(code.length()<4)) {
			if (test==coderCaractere(s.charAt(i))||coderCaractere(s.charAt(i))=='0'){
				i++;
			}
			else {
				test=coderCaractere(s.charAt(i));
				code+=test;
				i++;
			}
		}
		while (code.length()<4){
			code+=" ";
		}
		return code;
	}
}