
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char m= '0';
		switch (c) {
		case 'B' : m='1'; break; 
		case 'C' : m='2'; break;
		case 'D' : m='3'; break; 
		case 'F' : m='9'; break; 
		case 'G' : m='7'; break; 
		case 'J' : m='7'; break; 
		case 'K' : m='2'; break; 
		case 'L' : m='4'; break; 
		case 'M' : m='5'; break; 
		case 'N' : m='5'; break; 
		case 'P' : m='1'; break; 
		case 'Q' : m='2'; break; 
		case 'R' : m='6'; break; 
		case 'S' : m='8'; break; 
		case 'T' : m='3'; break;  
		case 'V' : m='9'; break; 
		case 'X' : m='8'; break; 
		case 'Z' : m='8'; break; 
		
		}
	return m;
	}

	

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String phrase="";
		for (int i =1 ; i< 5 ; i++) {
		
				phrase +=  coderCaractere(s.charAt(i));
				if (phrase.substring(i) == "0") {
					s = phrase.substring(i);
					s = "";
				}
		}
		return s.charAt(0) + phrase;
	}
	
	 
}
