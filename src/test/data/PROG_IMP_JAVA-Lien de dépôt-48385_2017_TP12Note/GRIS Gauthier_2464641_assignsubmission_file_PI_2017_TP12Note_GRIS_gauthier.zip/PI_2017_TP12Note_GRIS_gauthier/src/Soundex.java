
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char res;
		switch (c) {
			case 'B' : res ='1'; break;
			case 'P' : res ='1'; break;
			case 'C' : res ='2'; break;
			case 'K' : res ='2'; break;
			case 'Q' : res ='2'; break;
			case 'D' : res = '3'; break;
			case 'T' : res = '3'; break;
			case 'L' : res ='4'; break;
			case 'M' : res ='5'; break;
			case 'N' :res ='5'; break;
			case 'R' : res ='6'; break;
			case 'G' : res ='7'; break;
			case 'J' : res ='7'; break;
			case 'S' : res ='8'; break;
			case 'X' : res ='8'; break;
			case 'Z' :res ='8'; break;
			case 'F' : res ='9'; break;
			case 'V' : res ='9'; break;
			default : res ='0'; break;
				}
		return res;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = "";
		res += s.charAt(0);
		char temp;
		char temp2 = coderCaractere(s.charAt(0));
		s = s.substring(1);
		while (res.length()<4 && s.length()>0) {
			temp = s.charAt(0);
			if (coderCaractere(temp)!=temp2 && coderCaractere(temp)!='0') {
				res += coderCaractere(temp);
			} temp2 = res.charAt(res.length()-1);
			s = s.substring(1);
		} while (res.length()!=4) {
			res += " ";
		}
		return res;
	}
}
