
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		switch(c) {
			case 'B':
			case 'P':
				return '1';
			case 'C':
			case 'K':
			case 'Q':
				return '2';
			case 'D':
			case 'T':
				return '3';
			case 'L':
				return '4';
			case 'M':
			case 'N':
				return '5';
			case 'R':
				return '6';
			case 'G':
			case 'J':
				return '7';
			case 'S':
			case 'X':
			case 'Z':
				return '8';
			case 'F':
			case 'V':
				return '9';
			default:
				return '0';
		}

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {

		char[] soundex = new char[4];
		char[] string = s.toCharArray();
		soundex[0] = string[0];
		
		int i = 1;
		int j = 1;
		int n = string.length;
		char c = ' ';
		while(i<4) {
			if(j < n) {
				c = coderCaractere(string[j]);
				if(c != '0' && c != soundex[i-1]) {
					soundex[i] = c;	
					i++;
				}
				j++;
			}
			else {
				soundex[i] = ' ';
				i++;
			}
		}
		
		return ""+soundex[0]+soundex[1]+soundex[2]+soundex[3];

	}
}
