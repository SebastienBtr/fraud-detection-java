import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean contient(String nomFichier, String mot) {
		String ligne;
		boolean isFind = false;
		try {
			BufferedReader aLire= new BufferedReader(new FileReader(nomFichier));
			do {
				ligne = aLire.readLine();// On lit le nom
				if (ligne!=null) { // si on n'a pas atteint la fin du fichier...
					if(ligne.contains(mot))
						isFind = true;
				}
			} while (!isFind && ligne!=null); // tant qu'on n'a pas atteint la fin du fichier aLire
			aLire.close( ); // On ferme le fichier
		} catch (IOException e) {
			System.out.println("Une operation sur les fichiers a leve l'exception "+e);
		}
		
		return isFind;
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		int nb = 0;
		String ligne;
		
		File[] dir = dossier.listFiles();
		for(int i = 0; i<dir.length; i++) {
			if (dir[i].isDirectory())
				nb += nbContient(dir[i],mot);
			else {
				if(contient(dir[i].getAbsolutePath(),mot))
					nb++;
			}
		}
		return nb;
	}


}
