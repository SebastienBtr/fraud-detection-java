
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char res = '0';
		if (c=='B' || c=='P') {
			res = '1';
		}
		if (c == 'C' || c=='K' || c=='Q') {
			res = '2';
		}
		if (c == 'D' || c=='T') {
			res = '3';
		}
		if (c=='L') {
			res = '4';
		}
		if (c=='M'||c=='N') {
			res = '5';
		}
		if (c=='R') {
			res = '6';
		}
		if (c=='G'||c=='J') {
			res = '7';
		}
		if (c=='S'||c=='X'||c=='Z') {
			res = '8';
		}
		if (c=='F'||c=='V') {
			res = '9';
		}
		return res;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = "";
		res += s.charAt(0);
		for (int i = 1;i< s.length() && res.length()<=4;i++) {
			char trait = s.charAt(i);
			for(int k = 0;k<res.length();k++) {
				if(res.charAt(k)!=coderCaractere(trait)) {
					res += coderCaractere(trait);
				}
			}
		}
		
		return res;

	}
}
