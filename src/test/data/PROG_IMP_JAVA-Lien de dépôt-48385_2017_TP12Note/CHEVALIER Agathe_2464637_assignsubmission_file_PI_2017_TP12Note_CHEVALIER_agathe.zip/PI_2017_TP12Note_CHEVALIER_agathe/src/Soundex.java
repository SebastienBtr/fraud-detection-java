
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char[] charact�res = {'B','P','C','K','Q','D','T','L','M','N','R','G','J','S','X','Z','F','V'};
		char[] code = {'1','1','2','2','2','3','3','4','5','5','6','7','7','8','8','8','9','9'};
		for(int i=0; i<18; i=i+1) {
			if ( c==charact�res[i] ) {
				return(code[i]);
			} 
		}
		return('0');
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = "";
		res = res + s.charAt(0);
		int compte = 1;
		for (int i=1; i<s.length(); i=i+1) {
			if (compte == 4) {
				return(res);
			}
			if( coderCaractere( s.charAt(i)) == '0' ) {
				res = res;
			}
			if( coderCaractere( s.charAt(i)) != '0'){
				res = res + coderCaractere(s.charAt(i));
				compte = compte+1;
				}
		}
		return(res);
	}
}
