
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		String lettres = "BPCKQDTLMNRGJSXZFV";
		char caractere ='0';
		if (c==lettres.charAt(0)|| c==lettres.charAt(1)) {
			caractere= '1';
		}
		if (c==lettres.charAt(2)|| c==lettres.charAt(3) || c==lettres.charAt(4)){
			caractere= '2';
		}
		if (c==lettres.charAt(5) || c==lettres.charAt(6)) {
			caractere='3';
		}
		if (c==lettres.charAt(7)) {
			caractere='4';
		}
		if (c==lettres.charAt(8) || c==lettres.charAt(9)) {
			caractere='5';
		}
		if (c==lettres.charAt(10)) {
			caractere='6';
		}
		if (c==lettres.charAt(11) || c==lettres.charAt(12)) {
			caractere='7';
		}
		if (c==lettres.charAt(13)|| c==lettres.charAt(14) || c==lettres.charAt(15)){
			caractere='8';
		}
		if (c==lettres.charAt(16) || c==lettres.charAt(17)) {
			caractere='9';
		}
			
		return caractere; 

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code = ""+s.charAt(0);
		int n=s.length();
		int k=0;
		for (int i=1;i<n;i++) {
			char lettre = coderCaractere(s.charAt(i));
			if (lettre =='0' || lettre==code.charAt(k)) {
					code=code+"";
				}
			else {
			code=code+lettre;
			k++;
			}
		}
		if (code.length()>4) {
			return code.substring(0,4);
					}
		if (code.length()==1) {
			return code+" "+" "+" ";
		}
		if (code.length()==2) {
			return code+" "+" ";
		}
		if (code.length()==3) {
			return code+" ";
		}
		
		return code;
		
	}
}
