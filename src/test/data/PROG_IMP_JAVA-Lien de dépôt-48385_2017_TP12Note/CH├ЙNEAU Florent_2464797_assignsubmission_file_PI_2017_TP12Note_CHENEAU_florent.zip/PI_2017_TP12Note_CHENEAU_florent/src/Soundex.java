
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		switch (c) {
		case 'B' : return '1';
		case 'P' : return '1';
		case 'C' : return '2';
		case 'K' : return '2';
		case 'Q' : return '2';
		case 'D' : return '3';
		case 'T' : return '3';
		case 'L' : return '4';
		case 'M' : return '5';
		case 'N' : return '5';
		case 'R' : return '6';
		case 'G' : return '7';
		case 'J' : return '7';
		case 'S' : return '8';
		case 'X' : return '8';
		case 'Z' : return '8';
		case 'F' : return '9';
		case 'V' : return '9';
		default : return '0';
		}
		

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		
		String Soundex = "" + s.charAt(0);
		int i = 1;
		while(Soundex.length() < 4){
			if (i < s.length()) {
			
			char c = s.charAt(i);
			char d = Soundex.charAt(Soundex.length() - 1);
			char code = coderCaractere (c);
			if(code != d && code != '0') {
				Soundex = Soundex + code;
			}
			
			i+=1;
			}
			else {
				Soundex = Soundex + ' ';
			}
		}
		return Soundex; // A vous de completer

	}
}
