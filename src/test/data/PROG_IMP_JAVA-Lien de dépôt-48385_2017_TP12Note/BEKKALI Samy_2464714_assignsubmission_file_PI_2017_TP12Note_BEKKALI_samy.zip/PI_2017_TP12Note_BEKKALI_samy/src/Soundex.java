
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char n='0';
		switch(c) {
		case 'B' : n='1';break;
		case 'P' : n='1';break;
		case 'C' : n='2';break;
		case 'K' : n='2';break;
		case 'Q' : n='2';break;
		case 'D' : n='3';break;
		case 'T' : n='3';break;
		case 'L' : n='4';break;
		case 'M' : n='5';break;
		case 'N' : n='5';break;
		case 'R' : n='6';break;
		case 'G' : n='7';break;
		case 'J' : n='7';break;
		case 'S' : n='8';break;
		case 'X' : n='8';break;
		case 'Z' : n='8';break;
		case 'F' : n='9';break;
		case 'V' : n='9';break;
		default : n='0';
		}return n;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code="";
		code=code+s.charAt(0);
		for (int i=1;i<s.length();i++) {
			if(code.length()<4) {
			if (coderCaractere(s.charAt(i))=='0'){
				code=code;
		}
			else{
			code=code+coderCaractere(s.charAt(i));
			}
			if (code.charAt(i)==code.charAt(i-1)){
				code=code.substring(0, code.length()-1);}
		}
}
		if (code.length()<4) {
			code=code+" ";
		}
		return code;
}
}