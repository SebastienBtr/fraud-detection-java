
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		//String ent=c+"";
		//char S=ent.charAt(0);
		//int i=1;
		//while(S.length()<4) {
			//if (ent.charAt(i)=='B' || ent.charAt(i)=='P') {
				//S=S+"1";
			//}
			//if (ent.charAt(i)=='C' || ent.charAt(i)=='K') {
				//S=S+"2";
			//}
			//if (ent.charAt(i)=='D' || ent.charAt(i)=='T') {
				//S=S+"3";
			//}
			//i++;
		//}
		return c;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {

		return " "; // A vous de completer

	}
}
