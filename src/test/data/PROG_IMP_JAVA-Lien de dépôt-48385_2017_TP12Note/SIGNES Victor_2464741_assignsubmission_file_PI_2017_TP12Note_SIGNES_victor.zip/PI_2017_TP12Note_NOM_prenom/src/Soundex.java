
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char[][] t= {{'B','P','P'},{'C','K','Q'},{'D','T','T'},{'L','L','L'},{'M','N','N'},{'R','R','R'},{'G','J','J'},
				{'S','X','Z'},{'F','V','V'}};
		char[]t2= {'1','2','3','4','5','6','7','8','9'};
		char a='0';
		for(int i=0;i<t.length;i++) {
			for(int k=0;k<3;k++) {
				if (c==t[i][k]) {
					a=t2[i];
				}
			}
		}
		return a;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String a=s.substring(0, 1);
		for (int i=1;i<s.length();i++) {
			if (coderCaractere(s.charAt(i))!='0' && coderCaractere(s.charAt(i))!=coderCaractere(s.charAt(i-1)) && a.length()<4
					&& coderCaractere(s.charAt(i))!=a.charAt(a.length()-1)){
				a=a+coderCaractere(s.charAt(i));
			}
		}
		while(a.length()<4) {
			a=a+' ';
		}
		return a;

	}
}
