import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean contient(String nomFichier, String mot) {
		String res;
		try {
			BufferedReader aLire= new BufferedReader(new FileReader(nomFichier));
			do {
				res=aLire.readLine();
				if(res!=null) {
					if(res.length()>=mot.length()) {
				for (int i=0; i<res.length()-mot.length()+1;i++) {
					int j=0;
					int k=0;
					while(j<mot.length()) {
						if (mot.charAt(j)==res.charAt(j+i)) {
							k++;
						}j++;
					}if(k==mot.length()) {
						return true;
					}
				}
				}
				}
			}while(res!=null);
		aLire.close();
		}
		catch (IOException e) { 
			System.out.println("Une operation sur les fichiers a leve l'exception "+e);
	}
		return false;
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		int k=0;
		if(dossier.isFile()) {
			if(contient(dossier.getAbsolutePath(),mot)) {
				k++;
			}
		}else {
			File[] fils=dossier.listFiles();
			for(int i=0; i<fils.length;i++) {
				return k+nbContient(fils[i],mot);
			}
		}
	}


}
