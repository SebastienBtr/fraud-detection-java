import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean contient(String nomFichier, String mot) {
		
		String nom;
		try { 
			BufferedReader aLire= new BufferedReader(new FileReader(nomFichier));

			do {
				 
				nom = aLire.readLine();

				// si readline() retourne null c'est qu'on a atteint la fin du fichier
				if (nom!=null) { // si on n'a pas atteint la fin du fichier...
					if (nom == mot)
						return true;
					else
						return false;
				}
				
				
			} while (nom!=null); // tant qu'on n'a pas atteint la fin du fichier aLire


			// On ferme le fichier
			aLire.close( );
		}
		
		catch (IOException e) { 
			System.out.println("Une operation sur les fichiers a leve l'exception "+e);
		}
		return false; 
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		return -1; // cette fonction fait appel a la fonction contient qui ne fonctionne pas chez moi... 
	}


}
