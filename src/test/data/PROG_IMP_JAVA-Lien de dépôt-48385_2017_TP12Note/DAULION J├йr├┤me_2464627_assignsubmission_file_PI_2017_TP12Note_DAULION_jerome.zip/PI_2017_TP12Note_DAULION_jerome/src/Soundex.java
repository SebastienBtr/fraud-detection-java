
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char k='0';
		switch(c)
		{
		case 'B' :
		case 'P' : k='1';
		break;
		case 'C':
		case'K' :
		case 'Q' : k='2';
		break;
		case 'D' :
		case 'T' : k='3';
		break;
		case 'L' : k='4';
		break;
		case 'M' :
		case 'N' : k='5';
		break;
		case 'R' : k='6';
		break;
		case 'G' :
		case 'J' : k='7';
		break;
		case 'S' :
		case 'X' :
		case 'Z' : k='8';
		break;
		case 'F' :
		case 'V' : k='9';
		break;
		
		}
		return k;

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code=s.substring(0, 1);
		int i=1;
		while ((code.length()<4)&&(i<s.length())) {
			if((coderCaractere(s.charAt(i))!='0')&&(code.charAt(code.length()-1)!=coderCaractere(s.charAt(i)))) {
				code=code+coderCaractere(s.charAt(i));
				
			}
			i=i+1;
		}
		while (code.length()<4) {
			code=code+" ";
		}
		return code;

	}
}
