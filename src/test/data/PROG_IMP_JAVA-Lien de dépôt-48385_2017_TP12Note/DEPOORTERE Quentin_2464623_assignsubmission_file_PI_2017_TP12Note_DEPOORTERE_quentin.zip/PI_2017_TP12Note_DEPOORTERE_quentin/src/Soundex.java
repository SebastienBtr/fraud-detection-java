
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if (c=='B' || c=='P') {
			return '1';
		} else if (c=='C'||c=='K'||c=='Q') {
			return '2';
		} else if (c=='D'||c=='T') {
			return '3';
		} else if (c=='L') {
			return '4';
		} else if (c=='M'||c=='N') {
			return '5';
		} else if (c=='R') {
			return '6';
		} else if (c=='G'||c=='J') {
			return '7';
		} else if (c=='S'||c=='X'||c=='Z') {
			return '8';
		} else if (c=='F'||c=='V') {
			return '9';
		}
		return '0'; // A vous de completer

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = "";
		res = res+s.charAt(0);
		int n=s.length();
		s=s.substring(1,n);
		n=n-1;
		int i=0;
		while (res.length()<4 && n>=1) {
			if (coderCaractere(s.charAt(0))!='0') {
				if (coderCaractere(s.charAt(0))!=res.charAt(i)) {
					res+=coderCaractere(s.charAt(0));
					i++;
				}
			}
			s=s.substring(1,n);
			n=n-1;
		}
		while (res.length()<4) {
			res+= " ";
		}
		return res; 

	}
}
