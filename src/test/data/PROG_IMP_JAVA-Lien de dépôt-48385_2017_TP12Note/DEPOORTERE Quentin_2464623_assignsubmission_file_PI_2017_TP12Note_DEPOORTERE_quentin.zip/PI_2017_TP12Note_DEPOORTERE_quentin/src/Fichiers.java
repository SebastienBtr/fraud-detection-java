import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean contient(String nomFichier, String mot) {
		String ligne;
		int i;
		int m;
		int t;
		try {
			// On ouvre dans un premier temps le fichier
			BufferedReader aLire= new BufferedReader(new FileReader(nomFichier));
			// On remplit les instructions
			do {
				ligne=aLire.readLine();
				i=0;
				m=0;
				t=0;
				if(ligne!=null) {
					while (i<ligne.length()) {
						while(i+t<ligne.length() && ligne.charAt(i+t)==mot.charAt(m)) {
							if (m==mot.length()-1) {
								//On ferme le fichier
								aLire.close();
								return true;
							} else {
								m++;
								t++;
							}
						}
						t=0;
						m=0;
						i++;
						}
					}
			} while (ligne!=null);
			//On ferme le fichier
			aLire.close();
			return false;
		}
		catch (IOException e) { 
			System.out.println("Une operation sur les fichiers a leve l'exception "+e);
		}
		return false; // A VOUS DE COMPLETER
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		if (dossier.isFile()) {
			if (contient(dossier.getAbsolutePath(),mot)) {
				return 1;
			} else {
				return 0;
			}
		} else {
			File[] T= dossier.listFiles();
			int n=0;
			for (int i=0;i<T.length;i++) {
				n+=nbContient(T[i],mot);
			}
			return n;
		}

	}


}
