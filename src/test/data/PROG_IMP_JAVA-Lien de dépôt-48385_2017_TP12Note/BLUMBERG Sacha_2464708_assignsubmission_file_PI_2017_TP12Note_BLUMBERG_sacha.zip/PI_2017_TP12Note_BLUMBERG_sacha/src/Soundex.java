
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		String C="";
		C=C+c;
		char res='0';
		if(C.equals("B")||C.equals("P")) {
			res='1';
		}
		if(C.equals("C")||C.equals("K")||C.equals("Q")) {
			res='2';
		}
		if(C.equals("D")||C.equals("T")) {
			res='3';
		}
		if(C.equals("L")) {
			res='4';
		}
		if(C.equals("M")||C.equals("N")) {
			res='5';
		}
		if(C.equals("R")) {
			res='6';
		}
		if(C.equals("G")||C.equals("J")) {
			res='7';
		}
		if(C.equals("S")||C.equals("X")||C.equals("Z")) {
			res='8';
		}
		if(C.equals("F")||C.equals("V")) {
			res='9';
		}
		return res; 

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code=""+s.charAt(0);
		int i=1;
		while(code.length()<4&&i<s.length()) {
			if (coderCaractere(s.charAt(i))!='0'&&coderCaractere(s.charAt(i))!=code.charAt(code.length()-1)){
				code = code+coderCaractere(s.charAt(i));
			}
			i++;
		}
		while(code.length()<4) {
			code=code+" ";
		}
		return code; 

	}
}
