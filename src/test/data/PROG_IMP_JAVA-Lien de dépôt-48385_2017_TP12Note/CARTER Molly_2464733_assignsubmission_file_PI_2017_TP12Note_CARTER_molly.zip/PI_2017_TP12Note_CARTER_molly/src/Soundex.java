
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char s=0;
		if (c=='B'||c=='P') {
			s='1';
		} else if (c=='C'||c=='K'||c=='Q'){
			s='2';
		} else if (c=='D'||c=='T'){
			s='3';
		} else if (c=='L') {
			s='4';
		} else if (c=='M'||c=='N') {
			s='5';
		} else if (c=='R') {
			s='6';
		} else if (c=='G'||c=='J') {
			s='7';
		} else if (c=='S'||c=='X'||c=='Z') {
			s='8';
		} else if (c=='F'||c=='V') {
			s='9';
		} else {
			s='0';
		}

		return s; // OK

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res=""+s.charAt(0);
		int i=1;
		while (i<s.length()) {
			if (coderCaractere(s.charAt(i))!='0'&&coderCaractere(s.charAt(i-1))!=coderCaractere(s.charAt(i))) {
				res+=coderCaractere(s.charAt(i));
			}
			i++;
		}
		int j=res.length();
		if (j>4) {
			res=res.substring(0,4);
		} else {
		while (j<4) {
			res+=" ";
			j++;
		}}

		return res; // A vous de completer

	}
}
