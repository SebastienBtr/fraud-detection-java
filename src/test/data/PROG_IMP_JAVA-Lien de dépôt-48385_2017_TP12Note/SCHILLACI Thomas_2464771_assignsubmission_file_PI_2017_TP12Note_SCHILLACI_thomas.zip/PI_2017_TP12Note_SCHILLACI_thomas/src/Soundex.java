
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		String test = new String(c+"").toLowerCase();
		if("bp".contains(test)) return '1';
		if("ckq".contains(test)) return '2';
		if("dt".contains(test)) return '3';
		if("l".contains(test)) return '4';
		if("mn".contains(test)) return '5';
		if("r".contains(test)) return '6';
		if("gj".contains(test)) return '7';
		if("sxz".contains(test)) return '8';
		if("fv".contains(test)) return '9';
		return '0';
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = s.charAt(0)+"";
		
		for(int i=1; i<s.length(); i++) {
			char code = coderCaractere(s.charAt(i));
			if(code=='0' || (res.length()!=1 && code==res.charAt(res.length()-1))) continue;
			res+=code;
			if(res.length()==4) break;
		}
		
		while(res.length()<4) res+=" "; 
		
		return res;
	}
}
