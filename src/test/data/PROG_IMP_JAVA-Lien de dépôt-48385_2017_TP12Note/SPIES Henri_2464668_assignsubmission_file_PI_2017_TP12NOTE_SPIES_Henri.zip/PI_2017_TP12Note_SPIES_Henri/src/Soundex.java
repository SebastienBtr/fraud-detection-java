
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char type='0';
		if (c=='B' || c=='P') {
			type='1';
		};
		if (c=='K' || c=='C' ||c=='Q') {
			type='2';
		};
		if (c=='D' ||c=='T') {
			type='3';
		};
		if (c=='L') {
			type='4';
		};
		if (c=='M' || c=='N') {
			type='5';
		};
		if (c=='R') {
			type='6';
		};
		if (c=='G' || c=='J') {
			type='7';
		};
		if (c=='S' || c=='X' || c=='Z') {
			type='8';
		};
		if  (c=='F' || c=='V') {
			type='9';
		};
		return type;
		} 

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code=""+s.charAt(0); 
//je n'y arrive pas..
		return code; 

	}
}
