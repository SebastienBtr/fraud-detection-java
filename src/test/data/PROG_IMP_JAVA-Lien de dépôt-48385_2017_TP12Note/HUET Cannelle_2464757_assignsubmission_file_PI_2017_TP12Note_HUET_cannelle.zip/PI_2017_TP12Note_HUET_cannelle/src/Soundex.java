
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		
		if(c=='B' || c=='P') {
			return'1';
		}
		else if(c=='C'|| c=='K' || c=='Q') {
			return'2';
		}
		else if (c=='D' || c=='T') {
			return '3';
		}
		else if(c=='L') {
			return '4';
		}
		else if(c=='M'||c=='N') {
			return'5';
		}
		else if(c=='R') {
			return'6';
		}
		else if(c=='G'||c=='J') {
			return '7';
		}
		else if(c=='S'|| c=='X' || c=='Z') {
			return'8';
		}
		else if(c=='F'||c=='V') {
			return '9';
		}
		else {
			return'0';
		}
	}
	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String fin =""+s.charAt(0);
		s=s.substring(1, s.length());

		while(fin.length()<4 || fin.length()<s.length()) {
			if(coderCaractere(fin.charAt(fin.length()-1))== coderCaractere(s.charAt(1))) {
			s= s.substring(1, s.length());}
			else if (coderCaractere(s.charAt(1))=='0'){

				s= s.substring(1, s.length());
				
			}
			else {
			fin=fin+coderCaractere(s.charAt(0));
			s= s.substring(1, s.length());}}
		
			
				
		if (fin.length() <4) {
			for(int i=0; i<(4-fin.length()); i++) {
				fin=fin+" ";
				i++;}
	
}
		return fin;
	}
	}


