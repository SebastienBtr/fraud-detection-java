
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char res;
		 
		if (c=='P' || c=='B') {
			res='1';
		}else if (c=='C' || c=='K' || c=='Q') {
			res='2';
		}else if (c=='T' || c=='D') {
			res='3';
		}else if (c=='L') {
			res='4';
		}else if (c=='M' || c=='N') {
			res='5';
		}else if (c=='R') {
			res='6';
		}else if (c=='G' || c=='J') {
			res='7';
		}else if (c=='S' || c=='X' || c=='Z') {
			res='8';
		}else if (c=='F' || c=='V') {
			res='9';
		}else {
			res='0';
		}
		
		return res; // A vous de completer

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		
		char inter=s.charAt(0);
		String res="";
		res=res+inter;
		char x;
		int i=1;
		while ( res.length()<Math.min(s.length(), 4) && i<s.length()) {
			x=coderCaractere(s.charAt(i));
			if (x!=inter && x!='0') {
				res=res+x;
				inter=x;
			}
			
			i++;
		}
		if (res.length()<4) {
			while (res.length()<4) {
				res=res+" ";
			}
			
		}
		
		return res; // A vous de completer

	}
}
