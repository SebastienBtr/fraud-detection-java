
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char res=0;
		switch(c) {
			case 'B':
			case 'P': res='1';break;
			case 'C':
			case 'K':
			case 'Q': res='2';break;
			case 'D':
			case 'T': res='3';break;
			case 'L': res='4';break;
			case 'M':
			case 'N': res='5';break;
			case 'R': res='6';break;
			case 'G':
			case 'J': res='7';break;
			case 'S':
			case 'X':
			case 'Z': res='8';break;
			case 'F':
			case 'V': res='9';break;
			default: res='0';
		}
		return res;

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res=s.charAt(0)+""; //copie premier caractère
		int i=1;
		int n=s.length();
		char j;
		char jbis='0';
		while (res.length()<4 && i<=n-1) {
			j=coderCaractere(s.charAt(i));
			if (j!='0' && j!=jbis) {
				res+=j;
			}
			jbis=res.charAt(res.length()-1);
			i++;
		}
		while (res.length()<4) {
			res+=" ";
		}
		return res;

	}
}
