
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char r;
		if (c=='B' || c=='P') {
			r='1';
		} else if (c=='C' || c=='K' || c=='Q') {
			r='2';
		} else if (c=='D' || c=='T'){
			r='3';
		} else if (c=='L') {
			r='4';
		} else if (c=='M' || c=='N') {
			r='5';
		} else if (c=='R') {
			r='6';
		} else if (c=='G' || c=='J') {
			r='7';
		} else if (c=='S' || c=='X' || c=='Z') {
			r='8';
		} else if (c=='F' || c=='V') {
			r='9';
		} else {
			r='0';
		}
		return r;
		
		

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int n = s.length();
		String res=""+s.charAt(0);
		int m=0;
		if (n==1) {
			res+="   ";
		} else {
			for (int i=1;i<n;i++) {
				char c=coderCaractere(s.charAt(i));
				if (c!='0') {
					if (res.charAt(i-1)!=c && m<4) {
						res+=c;
						m+=1;
					}
				
				}
			}
		}
		if (m<4) {
			for (int j=0;j<(4-m);j++) {
				res+=" ";
			}
			
		}
		return res;


	}
}
