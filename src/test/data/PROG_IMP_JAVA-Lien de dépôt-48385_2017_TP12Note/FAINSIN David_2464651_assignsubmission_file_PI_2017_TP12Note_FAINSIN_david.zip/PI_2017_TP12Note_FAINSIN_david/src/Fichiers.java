import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean contient(String nomFichier, String mot) {
		String ligne;
		int n;
		int repere = 0;
		int compteur = 0;
		int taillemot = mot.length();
		try {
			BufferedReader aLire= new BufferedReader(new FileReader(nomFichier));
			ligne = aLire.readLine();
			while (ligne!=null) {
				n = ligne.length();
				while ((compteur<taillemot)&&(repere<n-taillemot+1)){
					if (ligne.charAt(compteur+repere)==mot.charAt(compteur)) {
						compteur ++;
					}
					else {
						compteur++;
						repere = repere+compteur;
						compteur = 0;
					}
				}
				repere = 0;
				ligne = aLire.readLine();	
			}
			aLire.close( );
		}
		catch (IOException e) { 
			System.out.println("Une operation sur les fichiers a leve l'exception "+e);
		}
		return (compteur == taillemot);
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		File[] list;
		int n ;
		int res=0;
		int i;
		if (dossier.isFile()) {
			if (contient(dossier.getName(),mot)) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			list = dossier.listFiles();
			n = list.length;
			for(i=0;i<n;i++);
			res = res + nbContient(list[i],mot);
			return res;
		}
	}


}
