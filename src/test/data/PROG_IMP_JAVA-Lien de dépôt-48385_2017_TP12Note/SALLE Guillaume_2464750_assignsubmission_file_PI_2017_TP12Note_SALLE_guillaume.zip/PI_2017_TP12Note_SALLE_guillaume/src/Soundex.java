
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char reponse = '0';
		if (c=='B' || c=='P') {
			reponse = '1';
		};
		if (c=='C' || c=='K' || c=='Q') {
			reponse = '2';
		};
		if (c=='D' || c=='T') {
			reponse = '3';
		};
		if (c=='L') {
			reponse = '4';
		};
		if (c=='M' || c=='N') {
			reponse = '5';
		};
		if (c=='R') {
			reponse = '6';
		};
		if (c=='G' || c=='J') {
			reponse = '7';
		};
		if (c=='S' || c=='X' || c=='Z') {
			reponse = '8';
		};
		if (c=='F' || c=='V') {
			reponse = '9';
		};
		return reponse;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = ""+s.charAt(0);
		int k = 1;
		int derniere_lettre = 0;
		while (res.length() < 4 && k<s.length()) {
			char chiffre = coderCaractere(s.charAt(k));
			if (chiffre=='0') {
				k++;
			} else {
				if (res.charAt(derniere_lettre)==chiffre) {
					k++;
				} else {
					res += chiffre;
					k++;
					derniere_lettre++;
				}
			}
		}
		while (res.length() < 4) {
			res+=' ';
		}
		
		return res;

	}
}
