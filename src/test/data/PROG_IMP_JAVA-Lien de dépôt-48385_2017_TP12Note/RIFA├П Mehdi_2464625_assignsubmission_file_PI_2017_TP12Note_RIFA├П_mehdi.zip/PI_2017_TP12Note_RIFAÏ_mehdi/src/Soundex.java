
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		switch (c) {
		case 'B':
		case 'P': return '1';
		case 'C':
		case 'Q':
		case 'K': return '2';
		case 'D':
		case 'T': return '3';
		case 'L': return '4';
		case 'M':
		case 'N': return '5';
		case 'R': return '6';
		case 'G':
		case 'J': return '7';
		case 'S':
		case 'X':
		case 'Z': return '8';
		case 'F':
		case 'V': return '9';
		default : return '0';
	
		
		}


	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int n=s.length();
		String code=s.charAt(0)+"";
		int m = 1;
		int i =1 ;
		while (i<n && m<4) {
			char p = coderCaractere(s.charAt(i));
			if (p!='0' && p!=code.charAt(m-1)) {
				code+=p+"";
				m++;
			}
			i++;
		}
		while(m<4) {
			code+=" ";
			m++;
		}
		return code; // A vous de completer

	}
}
