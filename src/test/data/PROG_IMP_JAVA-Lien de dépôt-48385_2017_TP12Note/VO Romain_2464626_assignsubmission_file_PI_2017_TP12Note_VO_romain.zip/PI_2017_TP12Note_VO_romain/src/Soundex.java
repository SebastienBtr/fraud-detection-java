
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere(char c) {
		char rec='c';
		if(c=='B' || c=='P') {
			rec='1';
		} else if (c=='C' || c=='K' || c=='Q') {
			rec='2';
		} else if (c=='D' || c=='T') {
			rec='3';
		} else if (c=='L') {
			rec='4';
		} else if (c=='M' || c=='N') {
			rec='5';
		} else if (c=='R') {
			rec='6';
		} else if (c=='G' || c=='J') {
			rec='7';
		} else if (c=='S' || c=='X' || c=='Z') {
			rec='8';
		} else if (c=='F' || c=='V') {
			rec='9';
		} else {
			rec='0';
		}
		return rec;
	}
	

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int n=s.length();
		char[] temp=new char[n];
		temp[0]=s.charAt(0);
		for(int i=1;i<n;i++) {
			temp[i]=coderCaractere(s.charAt(i));
		}
		String rep="";
		rep=rep+temp[0];
		int i=1;
		while(i<n && rep.length()<4) {
			if(i==n-1 && temp[i]==rep.charAt(rep.length()-1)) {
				rep=rep+" ";
			} else if(temp[i]!='0' && rep.charAt(rep.length()-1)!=temp[i]) {
				rep=rep+temp[i];
			}
			if(i<n-1) {
				if (i==n-1 && temp[i]==rep.charAt(rep.length()-1)) {
					i=i+2;
				}
				if(rep.charAt(rep.length()-1)==temp[i+1] || temp[i+1]=='0') {
					i=i+2;
				} else {
					i++;
				}
			} else {
				i++;
			}
		}
		while(rep.length()<4) {
			rep=rep+" ";
		}
		return rep;

	}
}
