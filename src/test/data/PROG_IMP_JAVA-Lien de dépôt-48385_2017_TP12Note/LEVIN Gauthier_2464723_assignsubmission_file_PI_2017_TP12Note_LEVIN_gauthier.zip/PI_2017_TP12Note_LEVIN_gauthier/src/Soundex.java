
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char car;
		if (c=='B'||c=='P') {
			car='1';
		}
		else if (c=='C' || c=='K' || c=='Q') {
			car='2';
		}
		else if (c=='D' || c=='T') {
			car='3';
		}
		else if (c=='L') {
			car='4';
		}
		else if (c=='M' || c=='N') {
			car='5';
		}
		else if (c=='R') {
			car='6';
		}
		else if (c=='G' || c=='J') {
			car='7';
		}
		else if (c=='S' || c=='X' || c=='Z') {
			car='8';
		}
		else if (c=='F' || c=='V') {
			car='9';
		}
		else {
			car='0';
		}
		return car; // A vous de completer

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String cod=""+s.charAt(0);
		for (int i=1;i<s.length();i++) {
			if (coderCaractere(s.charAt(i))!='0') {
				cod=cod+coderCaractere(s.charAt(i));
			}
		}
		for (int j=1 ; j<cod.length()-1;j++) {
			if (cod.charAt(j)==cod.charAt(j+1)) {
				if (j<cod.length()-2) {
					cod=cod.substring(0,j+1)+cod.substring(j+2,cod.length());
				}
				else {
					cod=cod.substring(0,j+1);
				}
			}
		}
		
		
		if (cod.length()>=4) {
			cod=cod.substring(0,4);
		}
		else {
			for (int k=cod.length()-1;k<3;k++) {
				cod=cod+" ";
			}
		}
		return cod; // A vous de completer

	}
}
