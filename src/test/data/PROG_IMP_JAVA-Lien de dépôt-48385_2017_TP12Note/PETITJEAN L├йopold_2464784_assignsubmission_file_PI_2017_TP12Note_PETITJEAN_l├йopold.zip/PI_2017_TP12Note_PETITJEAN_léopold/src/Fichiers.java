import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean match (String ligne,String filtre) {
		if(ligne.length()==0) {
			return filtre.length()==0 || (filtre.length()==1 && filtre.charAt(0)=='*');
		}
		if(filtre.length()==0) {
			return false;
		}
		if (filtre.charAt(0)=='?') {
			return match(ligne.substring(1),filtre.substring(1));
		} else {
			if (filtre.charAt(0)=='*') {
				return (match(ligne.substring(1),filtre.substring(1)) || match (ligne.substring(1),filtre) || match(ligne,filtre.substring(1)));
			}else {
				return ligne.charAt(0)==filtre.charAt(0) && match(ligne.substring(1),filtre.substring(1));
			}
		}
	}
	public static boolean contient(String nomFichier, String mot) {
		String ligne;
		boolean res =false;
		try { 
			BufferedReader aLire= new BufferedReader(new FileReader(nomFichier));

			do {
				ligne=aLire.readLine();
				if (ligne!=null) {
				res=match(ligne,'*'+mot+'*');}
			} while (ligne!=null && !res); // tant qu'on n'a pas atteint la fin du fichier aLire


			// On ferme le fichier
			aLire.close( );
			
		}
		catch (IOException e) { 
			System.out.println("Une operation sur les fichiers a leve l'exception "+e);
		}
		return res;
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		int compteur=0;
		if (dossier.isFile()) {
			if (contient(dossier.getAbsolutePath(),mot)) {
				compteur=1;
				return(compteur);
			} else {compteur=0;
			return compteur;}
		} else {
			File [] Liste =dossier.listFiles();
			for (int i=0;i<Liste.length;i++) {
				compteur =compteur +nbContient(Liste[i],mot);
			}
			return compteur;
		}// A VOUS DE COMPLETER
	}


}
