
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		switch(c) {
		case 'B':
		case 'P':return('1'); 
		case 'C':
		case 'K':
		case 'Q': return('2');
		case 'D':
		case 'T': return('3');
		case 'L': return('4'); 
		case 'M':
		case 'N': return('5');
		case 'R': return('6'); 
		case 'J':
		case 'G': return('7'); 
		case 'S':
		case 'X':
		case 'Z': return('8'); 
		case 'F':
		case 'V': return('9'); 
		default: return('0');}
		}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int length=s.length();
		String code=s.substring(0, 1);
		for(int k=1; k<length && code.length()<4; k+=1) {
			if(coderCaractere(s.charAt(k))!='0'&& code.charAt(code.length()-1)!=coderCaractere(s.charAt(k))) {
			code=code+ coderCaractere(s.charAt(k));}
			
		}
		while(code.length()<4) {
				code=code+" ";
			}
		return code;

	}
}
