
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if(c=='B'||c=='P') {
			return '1';
		}
		else {
			if(c=='C'||c=='K'||c=='Q') {
				return '2';
			}
			else {
				if(c=='D'||c=='T') {
					return '3';
				}
				else {
					if(c=='L') {
						return'4';
					}
					else {
						if(c=='M'||c==('N')) {
							return '5';
						}
						else {
							if(c=='R'){
								return '6';
							}
							else {
								if(c=='G'||c=='J') {
									return '7';
								}
								else {
									if(c=='S'||c=='X'||c=='Z'){
										return '8';
									}
									else {
										if(c=='F'||c=='V') {
											return '9';
											}
										else {
											return '0';
										}
									}
								}
							}
						}
					}
				}
			}
		}

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int n=s.length();
		String res="";
		for(int k=1;k<n;k++) {
			res=res+coderCaractere(s.charAt(k));
		}
		
		res=s.charAt(0)+res;
		int q=res.length();
		for(int h=0;h<q;h++) {
			for(int i=0;i<res.length();i++) {
				if(res.charAt(i)=='0') {
					res=res.substring(0,i)+res.substring(i+1,res.length());
				}	
			}
		}
		int v=res.length();
		for(int u=0;u<v;u++) {
			for(int r=0;r<res.length()-1;r++) {
				if(res.charAt(r)==res.charAt(r+1)) {
					res=res.substring(0,r)+res.substring(r+1,res.length());
				}
			}
		}
		for(int j=0;j<4;j++) {
			if(res.length()!=4) {
				res=res+" ";
			}
		}
		return res.substring(0,4);

	}
}
