
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if(c=='B'||c=='P') {
			char s= '1';
			return s;}
		else if(c=='C'||c=='K'||c=='Q') {char s='2';
		return s;}
		else if(c=='D'||c=='T') {char s='3';
		return s;}
		else if(c=='L') {char s='4';
		return s;}
		else if(c=='M'||c=='N') {char s='5';
		return s;}
		else if(c=='R') {char s='6';
		return s;}
		else if(c=='G'||c=='J') {char s= '7';
		return s;}
		else if(c=='S'||c=='X'||c=='Z') {char s='8';
		return s;}
		else if(c=='F'||c=='V') {char s='9';
		return s;}
		else {char s='0';
		return s;}
		}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int n=s.length();
		String s2=new String ("");
		s2=s2+s.charAt(0);
		int compt=1;
		int k=1;
		while(k<=n-1&&compt<4) {
			
			if(coderCaractere(s.charAt(k))!=s2.charAt(compt-1)&&coderCaractere(s.charAt(k))!='0') {
				s2=s2+coderCaractere(s.charAt(k));
				compt++;}
			k++;
		}
		if(compt==4) {return s2;}
		else { while(compt<4) {s2=s2+' ';
							compt++;}
				return s2;}
		}

	
}
