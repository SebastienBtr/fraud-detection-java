
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char k) {
		char c='0';
		if (k=='B' || k=='P')
			c='1';
		if (k=='C' || k=='K' || k=='Q')
			c='2';
		if (k=='D' || k=='T')
			c='3';
		if (k=='L')
			c='4';
		if (k=='M' || k=='N')
			c='5';
		if (k=='R')
			c='6';
		if (k=='G' || k=='J')
			c='7';
		if (k=='S' || k=='X' || k=='Z')
			c='8';
		if (k=='F' || k=='V')
			c='9';
		return c; // A vous de completer

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String mot=s.charAt(0)+"";
		for (int i=1;i<s.length();i++) {
			if (coderCaractere(s.charAt(i))!=mot.charAt(mot.length()-1) && coderCaractere(s.charAt(i))!='0') {
				mot+=coderCaractere(s.charAt(i));}}
		if (mot.length()>4){
			mot=mot.substring(0, 4);}
		if (mot.length()==1) {
			mot=mot+"   ";}
		if (mot.length()==2) {
			mot=mot+"  ";}	
		if (mot.length()==3) {
			mot=mot+" ";}

		return mot; // A vous de completer

	}
}
