
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char car;
			switch (c) {
			case 'B' :
			case 'P'  :car='1'; break;
			case 'C' :
			case 'K'  : 
			case 'Q' :car='2'; break;
			case 'D':
			case 'T' :car='3'; break;
			case 'L':car='4';break;
			case 'M':
			case 'N':car='5';break;
			case 'R':car='6';break;
			case 'G':
			case 'J' :car='7'; break;
			case 'S':
			case 'X':
			case 'Z': car='8';break;
			case 'F':
			case 'V':car='9';break;
			default : car='0';
			} return car;
		}


	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res=s.charAt(0)+"";
		for (int i=1;i<s.length()-1;i++) {
			char r=coderCaractere(s.charAt(i)) ;
			if (r!='0'|| r!=coderCaractere(s.charAt(i-1))) {
					res=res+r;
				
			} else {
				res=res;
			}
			
		} 
		if (res.length()<4) {
		do {
			res=res+" ";
		} while (res.length()<4);
		
	} return res.substring(0,5);
	}
}
