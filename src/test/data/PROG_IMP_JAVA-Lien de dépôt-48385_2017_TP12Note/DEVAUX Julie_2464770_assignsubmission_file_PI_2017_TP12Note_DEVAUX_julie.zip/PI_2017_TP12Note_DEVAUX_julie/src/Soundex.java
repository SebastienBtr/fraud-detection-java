
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char code;
		if (c=='B' || c=='P') {
			code='1';
		}else if (c=='C' || c=='K' || c=='Q') {
			code='2';
		}else if (c=='D' || c=='T') {
			code='3';
		}else if (c=='L') {
			code='4';
		}else if (c=='M' || c=='N') {
			code='5';
		}else if (c=='R') {
			code='6';
		}else if (c=='G' || c=='J') {
			code='7';
		}else if (c=='S' || c=='X' || c=='Z') {
			code='8';
		}else if (c=='F' || c=='V') {
			code='9';
		}else {
			code='0';
		}
		return code; 
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		int l=s.length();
		String code;
		code=s.substring(0, 1);
		int longueurcode=1;
		for(int i=1; i<l;i++) {
			char c=coderCaractere(s.charAt(i));
			if ((c!='0') && (c!=code.charAt(longueurcode-1) && longueurcode<4)){
				code=code+c;
				longueurcode++;
			}
		}
		if (longueurcode<4) {
			int nombrezero=4-longueurcode;
			for (int i=0;i<nombrezero;i++) {
				code+=" ";
			}
		}
		return code;
	}
	
	private static String toString(char charAt) {
		// TODO Auto-generated method stub
		return null;
	}
}
