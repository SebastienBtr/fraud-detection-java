
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if (c=='B'||c=='P') {
			return '1';
		}
		else if (c=='C'||c=='Q'||c=='K') {
			return'2';
		}
		else if (c=='D'||c=='T') {
			return'3';
		} 
		else if (c=='L') {
			return'4';
		}
		else if (c=='M'||c=='N') {
			return'5';
		}
		else if (c=='R') {
			return'6';
		}
		else if (c=='G'||c=='J') {
			return'7';
		}
		else if (c=='S'||c=='X'||c=='Z') {
			return'8';
		}
		else if (c=='F'||c=='V') {
			return'9';
		}
		else {
			return '0';
		}

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code="";
		String newcode="";
		code+=s.charAt(0);
		int i=1;
		while (i<s.length()) {
			char c= s.charAt(i);
			if(coderCaractere(c)!='0') {
				code+=coderCaractere(c);
			}
			i++;
						
		}
		newcode+= code.charAt(0);
		for (int k=1; k<code.length();k++) {
			if (code.charAt(k-1)!=code.charAt(k)) {
				newcode+=code.charAt(k);
			}
		}
		if (newcode.length()>=4) {
			return newcode.substring(0,4);
		}
		else {
			while (newcode.length()<4) {
				newcode+=" ";
			}
			return newcode;
		}
		 

	}
}
