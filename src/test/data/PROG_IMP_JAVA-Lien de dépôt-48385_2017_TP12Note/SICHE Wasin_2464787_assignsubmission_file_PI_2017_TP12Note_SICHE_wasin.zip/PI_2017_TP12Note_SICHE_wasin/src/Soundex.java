
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		switch(c) {
		case 'B' :
			return '1';
			
		case 'P':
			return '1';
		case 'C' :
			return '2';
			
		case 'K':
			return '2';
		case 'Q' :
			return '2';
			
		case 'D':
			return '3';
		case 'T' :
			return '3';
			
		case 'L':
			return '4';
		case 'M' :
			return '5';
			
		case 'N':
			return '5';
		case 'R' :
			return '6';
			
		case 'G':
			return '7';
			
		case 'J' :
			return '7';
			
		case 'S':
			return '8';
			
		case 'X' :
			return '8';
			
		case 'Z':
			return '8';
			
		case 'F' :
			return '9';
			
		case 'V':
			return '9';
			
			
			
			
		default: return '0';
			
		}

		

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res=s.substring(0,1);
		
		for (int i=1;i<s.length();i++) {
	
			if(coderCaractere(s.charAt(i))!='0' && (coderCaractere(s.charAt(i))!=coderCaractere(s.charAt(i-1))) && res.length()<=4)  {
				
				res=res+coderCaractere(s.charAt(i));
			
			}
			
		}
		if(res.length()>4) {
			res=res.substring(0,res.length()-1);
		
		
		}
		

		return res;

	}
}
