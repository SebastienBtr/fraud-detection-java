import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Fichiers {
	/**
	 * @param nomFichier, nomFichier!=null, le nom d'un fichier texte existant.
	 * @param mot, mot!=null
	 * @return Retourne true si le mot mot figure sur au moins l'une des lignes(*) du fichier texte de nom nomFichier
	 * (retourne false dans tous les autres cas).
	 * 
	 * (*) On ne cherche pas a determiner si un mot commence a la fin d'une ligne et se termine au debut
	 *     de la suivante : le mot doit etre integralement sur la ligne.
	 * 
	 */
	public static boolean contient(String nomFichier, String mot) {
		String ligne;
		boolean b = false;
		try {
			BufferedReader aLire = new BufferedReader(new FileReader(nomFichier));
			do {
				ligne = aLire.readLine();
				if (ligne != null) {
					int i = 0;
					while (i < ligne.length() - mot.length() + 1 && !b) {
						if (mot.equals(ligne.substring(i, i + mot.length()))) {
							b = true;
						}
						i++;
					}
				}
			
		}while (ligne != null && !b);
		aLire.close();
	}catch (IOException e) {
		System.out.println("Exception " +e+" levee");
	}
		return b;
	}

	/**
	 * @param dossier, dossier!=null, un dossier forme de sous-dossiers et de fichiers texte
	 * @param mot, mot!=null
	 * @return Retourne le nombre de fichiers figurant dans le dossier dossier et dans ses sous-dossiers qui contiennent
	 *  le mot mot sur au moins une de leurs lignes.
	 */
	public static int nbContient(File dossier, String mot) {
		if (dossier.isFile() && contient(dossier.getAbsolutePath(),mot)) {
			return 1;
		}else if (dossier.isFile()){
			return 0;
		}else {
			int s = 0;
			File[] t = dossier.listFiles();
			for (int i = 0; i<t.length;i++) {
				s = s + nbContient(t[i],mot);
			}
			return s;
		}
	}


}
