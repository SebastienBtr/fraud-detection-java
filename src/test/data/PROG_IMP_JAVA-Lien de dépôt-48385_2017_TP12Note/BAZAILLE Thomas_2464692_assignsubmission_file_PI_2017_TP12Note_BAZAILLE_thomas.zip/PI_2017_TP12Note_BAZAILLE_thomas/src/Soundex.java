
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if (c == 'B' || c == 'P') {
			return '1';
		}else if (c=='C' || c=='K' || c=='Q') {
			return '2';
		}else if (c == 'D' || c == 'T') {
			return '3';
		}else if (c == 'L') {
			return '4';
		}else if(c == 'M' || c == 'N') {
			return '5';
		}else if (c == 'R') {
			return '6';
		}else if (c == 'G' || c == 'J') {
			return '7';
		}else if (c == 'S' || c == 'X' || c == 'Z') {
			return '8';
		}else if(c == 'F' || c == 'V') {
			return '9';
		}else {
			return '0';
		}
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code = s.substring(0, 1);
		s = s.substring(1);
		while (s != "") {
			char c = coderCaractere(s.charAt(0));
			if (c != code.charAt(code.length()-1) && c != '0') {
				code = code + c;
			}
			s = s.substring(1);
		}
		while (code.length() < 4) {
			code = code + " ";
		}
		return code;
	}
}
