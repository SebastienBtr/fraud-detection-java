
public class Soundex {
	private static final boolean String = false;

	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		String res = "";
		if (c == c) {
			String B = res + "1" ; 
			String P = res + "1" ;
			String C = res + "2" ;
			String K = res + "2" ;
			String Q = res + "2" ;
			String D = res + "3" ;
			String T = res + "3" ;
			String L = res + "4" ;
			String M = res + "5" ;
			String N = res + "5" ;
			String R = res + "6" ;
			String G = res + "7" ;
			String J = res + "7" ;
			String S = res + "8" ;
			String X = res + "8" ;
			String Z = res + "8" ;
			String F = res + "9" ;
			String V = res + "9" ;
		}
		else {
			return res+'0' ;
		}

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {

		return " "; // A vous de completer

	}
}
