
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char code = '0';
		if (c == 'B' || c =='P')
			code = '1';
		if (c == 'C' || c =='K' || c == 'Q')
			code = '2';
		if (c == 'D' || c =='T')
			code = '3';
		if (c == 'L')
			code = '4';
		if (c == 'M' || c =='N')
			code = '5';
		if (c == 'R')
			code = '6';
		if (c == 'G' || c =='J')
			code = '7';
		if (c == 'S' || c =='X' || c == 'Z')
			code = '8';
		if (c == 'F' || c =='V')
			code = '9';
		return code;
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code = "";
		char c1 = ' ';
		char c2 = ' ';
		code = "" + s.charAt(0);
		for (int i = 1; i < s.length(); i ++) {
			if (code.length() != 4) {
				c1 = coderCaractere(s.charAt(i));
				if (c1 != '0' && c1 != c2) {
					code += c1;
					c2 = c1;
				}}}
		while(code.length() != 4)
			code += " ";
		return code; 

	}
}
