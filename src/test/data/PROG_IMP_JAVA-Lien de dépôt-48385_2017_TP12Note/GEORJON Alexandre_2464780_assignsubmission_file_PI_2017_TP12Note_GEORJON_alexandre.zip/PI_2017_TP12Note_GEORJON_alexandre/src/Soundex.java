
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char res='0';
		if(c=='B'||c=='P') {
			res='1';
		}else {
			if(c=='C'||c=='K'||c=='Q'){
				res='2';
			}else {
				if(c=='D'||c=='T'){
					res='3';
				}else {
					if(c=='L'){
						res='4';
					}else {
						if(c=='M'||c=='N'){
							res='5';
						}else {
							if(c=='R'){
								res='6';
							}else {
								if(c=='G'||c=='J'){
									res='7';
								}else {
									if(c=='S'||c=='X'||c=='Z'){
										res='8';
									}else {
										if(c=='F'||c=='V'){
											res='9';
										}
						
					}
		}
		}
		}
		}
				}
			}
		}
		
		return res;

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res=""+s.charAt(0);
		int i=1;
		int j=1;
		char suiv=' ';
		while(res.length()<4&&i<s.length()){
			suiv=Soundex.coderCaractere(s.charAt(i));
			if(!(res.charAt(j-1)==suiv||suiv=='0')) {
				res+=suiv;
				j++;
			}
			i++;
		}
		while(res.length()<4){
			res+=" ";
		}

		return res; // A vous de completer

	}
}
