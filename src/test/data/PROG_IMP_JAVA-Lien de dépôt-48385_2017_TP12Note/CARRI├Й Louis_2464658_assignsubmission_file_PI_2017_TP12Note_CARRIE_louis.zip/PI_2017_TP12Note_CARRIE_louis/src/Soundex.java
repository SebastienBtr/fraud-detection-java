
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		if (c=='B'||c=='P') {
			return '1';
		} else if (c=='C'||c=='K'||c=='Q') {
				return '2';
		} else if (c=='D'||c=='T') {
			return '3';
		} else if (c=='L') {
			return '4';
		} else if (c=='M'||c=='N') {
			return '5';
		} else if (c=='R') {
			return '6';
		} else if (c=='G'||c=='J') {
			return '7';
		} else if (c=='S'||c=='X'||c=='Z') {
			return '8';
		} else if (c=='F'||c=='V') {
			return '9';
		} else {
			return '0';
		}

	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String res = "";
		if (s!="") {
		res = res + s.charAt(0);
		s = s.substring(1,s.length());
		int i = 1;
		while ((s.length()!=0)&&(i<4)) {
			if (coderCaractere(s.charAt(0))!='0'&&
					coderCaractere(s.charAt(0))!=res.charAt(res.length()-1)) {
				res = res + coderCaractere(s.charAt(0));
				i += 1;
			} else {
				s = s.substring(1,s.length());
			}
		}
		int j = res.length();
		if (j<4) {
			for (int k=0; k<(4-j); k++) {
				res = res + " ";
			}
		}
		return res; // A vous de completer

	} else {
		return "    ";
	}
}
}
