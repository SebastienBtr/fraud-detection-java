
public class Soundex {
	/**
	 * 
	 * @param c, un caractere quelconque
	 * @return Retourne le caractere correspondant a c dans la table 
	 * des correspondances ('1' pour 'B' et 'P', '2' pour 'C', 'K' et 'Q', ...) 
	 * si c est un caractere majuscule figurant dans la table.
	 * Sinon, retourne '0'.
	 */
	public static char coderCaractere( char c) {
		char code=' ';
		if(!((c=='B')||(c=='C')||(c=='D')||(c=='F')||(c=='G')||(c=='J')||(c=='K')||(c=='L')||(c=='M')||(c=='N')||(c=='P')||(c=='Q')||(c=='R')||(c=='S')||(c=='T')||(c=='V')||(c=='X')||(c=='Z'))) {
			return '0';
		}else {
			if((c=='B')||(c=='P')) {
				code='1';
			}else if((c=='C')||(c=='Q')||(c=='K')) {
				code='2';
			}else if((c=='D')||(c=='T')) {
				code='3';
			}else if((c=='L')) {
				code='4';
			}else if((c=='M')||(c=='N')) {
				code='5';
			}else if((c=='R')) {
				code='6';
			}else if((c=='G')||(c=='J')) {
				code='7';
			}else if((c=='S')||(c=='X')||(c=='Z')) {
				code='8';
			}else {
				code='9';
			}
		}
		return code; 
	}

	/**
	 * @param s, une chaine correspondant a un nom propre en majuscules. s.length()>=1.
	 * @return Retourne le code soundex de s.
	 */
	public static String coder(String s) {
		String code=s.charAt(0)+"";
		for(int i=1;i<s.length();i++) {
			char c=coderCaractere(s.charAt(i));
			if(c=='0'){
				code=code;
			}else if((i>1)&&(c==coderCaractere(s.charAt(i-1)))){
				code=code;
			}else {
				code=code+c;
			}
		}if(code.length()>4) {
			code=code.substring(0, 4);
		}else {
			for(int i=0;i<4-code.length();i++) {
				code=code+" ";
			}
		}
		return code; 
	}
}
