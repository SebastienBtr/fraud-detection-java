
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s, int index) {
		int nb = 0 ;
		String res = s ;
		if (s.contains("a")||s.contains("e")||s.contains("i")||s.contains("o")||s.contains("u")||s.contains("y")) {
			nb++ ;
			res = s.substring(index);
		}
				
		
		return nb;
	}	
 public static int nbVoyelles(String s) {
	 return nbVoyelles(s, s.length()-1);
 }
 
}
