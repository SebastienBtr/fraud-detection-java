
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	
	//public static int nbVoyelles(String s) {
		
		//return nbVoyellesComplementaire(s,s.length()-1,A,E,I,O,U,Y);
	//}	
	
	public static int nbVoyellesComplementaire(String s, int pos) {
		if (pos==0){
			return 0;}
		else {
	//		if (s.charAt(pos)== char(A) || s.charAt(pos)== char(E) || s.charAt(pos)== char(I) || s.charAt(pos)==char(O) || s.charAt(pos)==char(U) || s.charAt(pos)==char(Y)) {
				return 1+nbVoyellesComplementaire(s, pos-1);
			}
		//	else {
	//			return nbVoyellesComplementaire(s, pos-1);
			}
				
		//}
	}
//}
