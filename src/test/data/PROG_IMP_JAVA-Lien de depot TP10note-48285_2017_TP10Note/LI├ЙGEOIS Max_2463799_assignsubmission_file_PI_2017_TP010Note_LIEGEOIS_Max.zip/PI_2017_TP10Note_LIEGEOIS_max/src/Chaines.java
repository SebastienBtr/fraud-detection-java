
public class Chaines {
	/**
	 * @param s, une chaine de caracteres. s!=null. 
	 * @param lg, un entier positif. lg>=0.
	 * @return Si s comporte moins de lg caracteres, retourne s.
	 * Sinon, retourne la chaine formee des lg premiers caracteres de s
	 * (le debut de longueur lg de s).
	 * Ex.:  debut("abcde",10) retourne "abcde"
	 *       debut("abcde", 5) retourne "abcde"
	 *       debut("abcde", 4) retourne "abcd"
	 *       debut("abcde", 1) retourne "a"
	 *       debut("abcde", 0) retourne ""
	 * 
	 * VERSION RECURSIVE : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 * Toutes les methodes de la classe String sont utilisables mais votre code doit etre recursif
	 */
	public static String debutRec(String s, int lg) {
		String t;
		if (s.length()<lg) {
			return s;
		}
		else if (lg==0) {
			return "";
			}
		else if (lg==1){
			t=new String(""+s.charAt(0));
		}
		else {
			t=""+debutRec(s,lg+1);
		}
		return t;
	}

	/**
	 * Specifications identiques a celles de debutRec mais version iterative.
	 * 
	 * VERSION ITERATIVE : VOTRE CODE NE DOIT PAS ETRE RECURSIF !!!
	 * 
	 * Vous pouvez utiliser les methodes de la classe String a l'exception 
	 * de la fonction subString(int i, int j) 
	 */
	public static String debutIte(String s, int lg) {
		String s1;
		if (lg==0) {
			s1="";
		}
		else if (s.length()<lg) {
			s1=s;
		}
		else {
			s1=new String(""+s.charAt(0));
			for (int i=1;i<lg;i++) {
				s1=s1+""+s.charAt(i);
			}
		}
		return s1;
	}

	/**
	 * 
	 * @param s, une chaine de caracteres. s!=null
	 * @param lg, un entier positif. lg>=0.
	 * @return Si s comporte moins de lg caracteres, retourne s.
	 * Sinon, retourne la chaine formee des lg derniers caracteres de s
	 * (la fin de longueur lg de s).
	 * Ex.:  fin("abcde",10) retourne "abcde"
	 *       fin("abcde", 5) retourne "abcde"
	 *       fin("abcde", 4) retourne "bcde"
	 *       fin("abcde", 1) retourne "e"
	 *       fin("abcde", 0) retourne ""
	 * 
	 * VERSION RECURSIVE : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 * Toutes les methodes de la classe String sont utilisables mais votre code doit etre recursif
	 */
	public static String finRec(String s, int lg) {
		return ""; // A VOUS DE COMPLETER
	}

	/**
	 * Specifications identiques a celles de finRec mais version iterative.
	 * 
	 * VERSION ITERATIVE : VOTRE CODE NE DOIT PAS ETRE RECURSIF !!!
	 * 
	 * Vous pouvez utiliser les methodes de la classe String a l'exception 
	 * de la fonction subString(int i, int j) 
	 */
	public static String finIte(String s, int lg) {
		String s2;
		if (lg==0) {
			s2="";
		}
		else if (s.length()<lg) {
			s2=s;
		}
		else {
			s2=new String(""+s.charAt(s.length()-1));
			for (int j=1;j<lg;j++) {
				s2=s.charAt(s.length()-1-j)+""+s2;
			}
		}
		return s2;
	}
}
