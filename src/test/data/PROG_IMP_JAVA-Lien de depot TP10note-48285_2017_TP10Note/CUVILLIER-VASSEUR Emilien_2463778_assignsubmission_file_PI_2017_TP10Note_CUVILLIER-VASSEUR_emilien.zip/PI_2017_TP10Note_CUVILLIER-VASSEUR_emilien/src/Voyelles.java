
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	
	public static boolean test(char s) {
		if (s=='A'||s=='E'||s=='I'||s=='O'||s=='U'||s=='Y') {
			return true;
		}
		else {
			return false;
		}
	}
	public static int nbVoyelles(String s) {
		int n=s.length();
		char x=s.charAt(n-1);
		if ((n==1)&&test(x)) {
			return 1;
		}
		else {
			if (test(x)) {
				return 1+nbVoyelles(s.substring(0,n-1));
			}
			else {
				return nbVoyelles(s.substring(0,n-1));
			}
		}
		
		// A VOUS DE COMPLETER
	}	
}
