public class NombresTriangulaires {

	/**
	 * @param n, un entier positif (n>=0)
	 * @return Retourne le nombre triangulaire Tn
	 * Exemple : triangulaire(6) retourne 21.
	 * 
	 * ATTENTION : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 */
	public static int triangulaire(int n){
		if (n==0) {
			return 0;
		}
		if (n==1) {
			return 1;
		}else {
			return (n*triangulaire(1)+triangulaire(n-1));
		}
		
		
		// A VOUS DE COMPLETER	
	}
}
