
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static boolean IntVoyelles(String s) {
		String v="AEIOUY";
		for (int i=0; i<v.length(); i++) {
			if (s.charAt(0)==v.charAt(i)) {
				return true;
			}
		}
		return false;
	}
	public static int nbVoyelles(String s) {
		int n=s.length();
		if (n==0) {
			return 0;
		}
		if (IntVoyelles(s)==false) {
			return nbVoyelles(s.substring(1,n));
		}else {
			return 1+nbVoyelles(s.substring(1, n));
		}
	}	
}
