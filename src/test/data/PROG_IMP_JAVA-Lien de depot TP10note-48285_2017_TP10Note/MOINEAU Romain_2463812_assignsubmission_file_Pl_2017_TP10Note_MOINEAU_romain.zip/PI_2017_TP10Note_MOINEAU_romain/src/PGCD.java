public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		int pgcd = 0;
		if (a==0 || b==0) {
			pgcd = 0;
		} else {
			if (a<=b) {
				if(b%a == 0) {
					pgcd = a;
				} else {
					pgcd = pgcdRec(a,b-a);
				}
			} else {
				if (a%b == 0) {
					pgcd = b;
				} else {
					pgcd = pgcdRec(a-b,b);
				}
			}
		}
		return pgcd;	
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		return -1;	
	}
}
