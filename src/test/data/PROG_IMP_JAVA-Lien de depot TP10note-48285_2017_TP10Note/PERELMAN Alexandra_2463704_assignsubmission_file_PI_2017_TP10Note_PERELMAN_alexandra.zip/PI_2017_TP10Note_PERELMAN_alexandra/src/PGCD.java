public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return a; }
		else {
			if (a==1 || b==1) {
				return 1; }
			else {
				return pgcdRec(Math.min(a,b), Math.max(a,b)-Math.min(a, b)); 
			}
			}
	}}
	
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	//public static int pgcdIte(int a, int b) { 
	//	int pgcd;
	//	if (a==b) {
	//		return a; }
	//	else {
	//		while (a!=1 && b!=1) {
		//		pgcd=Math.max(a,b)-Math.min(a, b);
		//	} }}}