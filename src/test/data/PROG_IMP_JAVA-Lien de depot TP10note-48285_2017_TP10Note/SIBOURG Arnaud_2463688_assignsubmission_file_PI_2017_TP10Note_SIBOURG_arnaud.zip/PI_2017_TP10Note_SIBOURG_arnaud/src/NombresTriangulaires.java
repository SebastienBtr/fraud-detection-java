public class NombresTriangulaires {

	/**
	 * @param n, un entier positif (n>=0)
	 * @return Retourne le nombre triangulaire Tn
	 * Exemple : triangulaire(6) retourne 21.
	 * 
	 * ATTENTION : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 */
	public static int triangulaire(int n){
		int i =0;
		int t=0;
		t= t+i;
		if (i<n) {
			triangulaire(i+1);
		}
		return t;
	}
}
