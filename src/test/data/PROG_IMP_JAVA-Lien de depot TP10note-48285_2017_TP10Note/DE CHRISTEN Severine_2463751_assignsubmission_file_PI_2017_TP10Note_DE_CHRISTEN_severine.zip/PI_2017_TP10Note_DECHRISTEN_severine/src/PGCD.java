public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		int min;
		int max;
		if (a==b) {
			return a;
		}
		else {
			if(a<b) {
				min=a;
				max=b;
			}
			else {
				min=b;
				max=a;
			}
			return (pgcdRec(min,max-min));
		}
	// A VOUS DE COMPLETER	
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
	
		return -1;// A VOUS DE COMPLETER	
	}
}
