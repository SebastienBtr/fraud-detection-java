
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int nbr=0;
		// int n=s.length();
		
		//if (s.length()==0) {
			//return nbr;
		//}
		// if (s.charAt(n)=='A'|| s.charAt(n)=='E' || s.charAt(n)=='I'||
			//	s.charAt(n)=='O'|| s.charAt(n)=='U'|| s.charAt(n)=='Y') {
		//nbr++;
	//}
		//nbVoyelles(s.substring(0,n-2));
		return nbr;
			
	}	
}
