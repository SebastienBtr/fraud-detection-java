
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (voyelle(s)) {
			return 1;
		}else {
			if (voyelle(s.charAt(0))) {
				return nbVoyelles(s) + 1;
			}
			return nbVoyelles(s);
		}
	}	
	public static boolean voyelle(char s) {
		return s.equals("A")||s.equals("E")||s.equals("I")||s.equals("O")||s.equals("U")||s.equals("Y");
	}
}
