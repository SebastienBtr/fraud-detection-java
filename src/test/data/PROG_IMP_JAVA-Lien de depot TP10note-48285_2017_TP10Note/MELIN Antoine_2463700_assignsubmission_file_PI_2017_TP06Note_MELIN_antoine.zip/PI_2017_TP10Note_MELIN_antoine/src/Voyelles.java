
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int c=0;
		int n=s.length();
		if (n==0) {
			return c;
		}if  (s.charAt(n-1)=='A' || s.charAt(n-1)=='E' || s.charAt(n-1)=='I' || s.charAt(n-1)=='O' || s.charAt(n-1)=='U' || s.charAt(n-1)=='Y') {
		c++;
		return nbVoyelles(s.substring(0,n-1));
	} else {
		return nbVoyelles(s.substring(0,n-1));
}
	}
}