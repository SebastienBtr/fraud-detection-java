public class NombresTriangulaires {

	/**
	 * @param n, un entier positif (n>=0)
	 * @return Retourne le nombre triangulaire Tn
	 * Exemple : triangulaire(6) retourne 21.
	 * 
	 * ATTENTION : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 */
	public static int triangulaire(int n){
		if (n==0) {
			return 0;
		} else {
		return triangulaire(n-1)+n;
		}
	}
		
}
