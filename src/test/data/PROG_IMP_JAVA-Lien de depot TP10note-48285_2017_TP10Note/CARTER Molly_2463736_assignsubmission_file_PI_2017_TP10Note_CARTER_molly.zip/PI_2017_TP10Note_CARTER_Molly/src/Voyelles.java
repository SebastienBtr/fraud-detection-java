
public class Voyelles {
	
	public static boolean testV (String l) {
		String[] v= {"A","E","I","O","U","Y"};
		boolean test=false; int i=0;
		while (i<v.length) {
			if (l==v[i]) {
				test=true;
				i=v.length;
			}
			i++;
		}
		return test;
	}

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length()==1) {
			if (testV(s)) {
				return 1;
			} else {
				return 0;
			}
		} else if (testV((s.charAt(s.length()-1)+""))){
			return 1+ nbVoyelles(s.substring(0, s.length()-1));
		} else {
			return 0+ nbVoyelles(s.substring(0, s.length()-1));
		}
		 // A VOUS DE COMPLETER
	}	
}
