
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length()<=0) {
			return 0;
		}
		if (s.length()==1) {
			switch (s.charAt(0)) {
				case 'A' :
					return 1;
				case 'E' :
					return 1;
				case 'I' :
					return 1;
				case 'O' :
					return 1;
				case 'U':
					return 1;
				case 'Y' :
					return 1;
				default :
					return 0;
			}
		}else {
				return nbVoyelles(s.substring(0, s.length()/2))+nbVoyelles(s.substring(s.length()/2));
			}
	}	
}
