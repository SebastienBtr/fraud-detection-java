
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length()==1){
			return voyelle(s);
		}else {
			//return nbVoyelles(s.subString(0, (s.length())%2))+nbVoyelles(s.subString(s.length()%2,s.length()));
		}
		return 0;
	}
	public static int voyelle(String s) {
		if (s=="A"||s=="E"||s=="I"||s=="O"||s=="U"||s=="Y") {
			return 1;
		}else {
			return 0;
		}
	}
}