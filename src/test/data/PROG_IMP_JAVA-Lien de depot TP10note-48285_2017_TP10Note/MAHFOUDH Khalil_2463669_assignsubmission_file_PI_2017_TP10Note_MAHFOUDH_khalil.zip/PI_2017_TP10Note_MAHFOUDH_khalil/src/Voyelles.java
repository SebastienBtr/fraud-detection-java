
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int count = 0;
		if (est_voyelle(s.charAt(0))) {
			count += 1;
			return 1;
		}
		else {
			//nbVoyelles(s.substring(1, s.length()));
			//return count;
			return -1;
		}
		
	}
	
	public static boolean est_voyelle(char c) {
		if (c == 'a') {
			return true;
		}
		else if (c == 'e') {
			return true;
		}
		else if (c == 'i') {
			return true;
		}
		else if (c == 'o') {
			return true;
		}
		else if (c == 'u') {
			return true;
		}
		else if (c == 'y') {
			return true;
		}
		else {
			return false;
		}
	}
}
