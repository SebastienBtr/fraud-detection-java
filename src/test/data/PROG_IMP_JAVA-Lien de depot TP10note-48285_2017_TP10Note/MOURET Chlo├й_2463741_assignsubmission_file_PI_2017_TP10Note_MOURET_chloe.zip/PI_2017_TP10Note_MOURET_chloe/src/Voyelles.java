
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	
	public static int nbVoyellesbis(String s, int n) {
		if (n==0) {
			if (s.charAt(0)=='A' || s.charAt(0)=='E' || s.charAt(0)=='I' || s.charAt(0)=='O' ||s.charAt(0)=='U'||s.charAt(0)=='Y' ) {return 0;}
			else {return 0;}
		}
		else {
			if (s.charAt(n-1)=='A' || s.charAt(n-1)=='E' || s.charAt(n-1)=='I' || s.charAt(n-1)=='O' ||s.charAt(n-1)=='U'||s.charAt(n-1)=='Y' ) {return 1+nbVoyellesbis(s,n-1);}
			else {return nbVoyellesbis(s,n-1);}
		}
	}
	
	
	
	public static int nbVoyelles(String s) {
		return nbVoyellesbis(s,s.length());
	}	
}
