/**
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	
	/**
	
	public static int nbVoyelles(String s) {
		int nb=0;
		if (s=="A"||s=="E"||s=="I"||s=="O"||s=="U"||s=="Y") {
				nb++;
				return nb;
		}
		else {
			if (s.substring(0,2)=="A"||s.substring(0,2)=="E"||s.substring(0,2)=="I"||s.substring(0,2)=="O"||s.substring(0,2)=="U"||s.substring(0,2)=="Y") {
				nb++;
			return(nbVoyelles(s.substring(1,s.length())));
			}
			}
	}
}
*/
			
		
	
