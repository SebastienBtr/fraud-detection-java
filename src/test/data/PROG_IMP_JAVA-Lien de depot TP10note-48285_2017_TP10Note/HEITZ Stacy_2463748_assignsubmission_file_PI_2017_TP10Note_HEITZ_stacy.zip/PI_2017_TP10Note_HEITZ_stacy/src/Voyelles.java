
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	
	public static int nbvoy(String s, int i) {
		String p=s.substring(0,0);
		if (i==0 && (p=="A" || p=="E" || p=="I" || p=="U"|| p=="Y"||p=="O")){
			return 1;
		} else if	(i==0 && p!="A" && p!="E" && p!="I" && p!="U"&& p!="Y" ) {
				return 0;
	} else {
		String t=s.substring(i, i);
		if (t=="A" || t=="E" || t=="I" || t=="U"|| t=="Y" || t=="O" ) {
			return 1+nbvoy(s,i-1);
		}else {
			return nbvoy(s,i-1);
		}
	}
	}
	
	
	
	public static int nbVoyelles(String s) {
		return (nbvoy(s,s.length()-1));
		}
	}	

