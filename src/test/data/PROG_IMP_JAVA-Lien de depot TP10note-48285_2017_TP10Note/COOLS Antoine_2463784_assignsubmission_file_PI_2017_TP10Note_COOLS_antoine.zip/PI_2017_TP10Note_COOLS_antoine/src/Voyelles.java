
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		return 0;
	}
		/*if(s==null) {
			return 0;
		}
		else {
			int l=s.length();
			if(s.charAt(l)=='O' || s.charAt(l)=='A'||s.charAt(l)=='U'||s.charAt(l)=='I'||s.charAt(l)=='E') {
				return nbVoyelles((s.substring(0,l)))+1;
			}
			else {
				return 0;
			}
		}
	}*/	
}
