
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if(s.length()==1) {
			return estVoyelle(s);
		}
		
		else {
			return nbVoyelles(s.substring(1, s.length())) + estVoyelle(s.substring(0,1));
		}
	}
	
	public static int estVoyelle(String L) {
		if(L == "A" || L == "E" || L == "I" || L == "O" || L == "U" || L == "Y") {
			return 1;
		}
		
		else {
			return 0;
		}
	}
}
