public class Index {

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus grand i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int lastIndexOf(int[] t, int pos, int valeur) {
		return -1;	
	}

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus petit i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int firstIndexOf(int[] t, int pos, int valeur) {
		return -1;// A VOUS DE COMPLETER	
	}
}
