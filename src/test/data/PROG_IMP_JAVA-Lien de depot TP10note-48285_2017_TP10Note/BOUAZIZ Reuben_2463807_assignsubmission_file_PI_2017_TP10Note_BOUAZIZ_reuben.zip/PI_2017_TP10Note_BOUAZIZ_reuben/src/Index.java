public class Index {

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus grand i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int lastIndexOf(int[] t, int pos, int valeur) {
		int[] t1;
		t1 = new int[pos];
		for (int i=0;i<pos;i++) {
			t1[i]=t[i];
		}
		if (t1.length==1) {
			if (t1[0]==valeur) {
				return 0; 
			}
			else {
				return -1;
			}
		}
		if (t1[pos-1]==valeur && pos-1>0) {
			return pos-1;
		}
		else {
			return lastIndexOf(t1,pos-1,valeur);
		}
	}

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus petit i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int firstIndexOf(int[] t, int pos, int valeur) {
		return -1;
	}
}
