public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return a;
		}
		else {
			if (a>=b) {
			return pgcdRec(b,a-b);
		}
			else {
				return pgcdRec(a,b-a);
			}
	}
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		if (a==b) {return a;}
		int c=1;
		for (int i=1;i<Math.max(a,b);i++) {
				if (a%i==0 && b%i==0 && i>c) {
					c=i;
				}
			}

		return c;
	}
}

