
public class Trigonometrie {

	public static final double EPSILON = 0.001;

	/**
	 * @param x, un nombre a virgule flottante positif (x>=0)
	 * @return Retourne le sinus de l'angle x
	 * ATTENTION : 
	 * - Votre code doit etre RECURSIF et s'appuyer sur les formules de l'enonce.
	 * - Vous ne pouvez pas utiliser les methodes de la classe Math.
	 * - Vous ne pouvez pas faire appel a d'autres methodes que sinusRec et cosinusRec
	 */
	public static double sinusRec(double x) {
		double sinus;
		if (x<=EPSILON) sinus=x;
		else sinus = 2*sinusRec(x/2)*cosinusRec(x/2);
		return sinus;
	}

	/**
	 * @param x, un nombre a virgule flottante positif (x>=0)
	 * @return Retourne le cosinus de l'angle x
	 * ATTENTION : 
	 * - Votre code doit etre RECURSIF et s'appuyer sur les formules de l'enonce.
	 * - Vous ne pouvez pas utiliser les methodes de la classe Math.
	 * - Vous ne pouvez pas faire appel a d'autres methodes que cosinusRec
	 */
	public static double cosinusRec(double x) {
		double cosinus;
		if (x<=EPSILON) cosinus=1-x*x/2;
		else cosinus = 2*cosinusRec(x/2)*cosinusRec(x/2)-1;
		return cosinus;
	}

}
