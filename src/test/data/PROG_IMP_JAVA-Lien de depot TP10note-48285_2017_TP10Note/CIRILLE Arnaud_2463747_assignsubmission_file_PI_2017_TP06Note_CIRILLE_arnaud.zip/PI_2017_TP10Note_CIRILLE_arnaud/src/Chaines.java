
public class Chaines {
	/**
	 * @param s, une chaine de caracteres. s!=null. 
	 * @param lg, un entier positif. lg>=0.
	 * @return Si s comporte moins de lg caracteres, retourne s.
	 * Sinon, retourne la chaine formee des lg premiers caracteres de s
	 * (le debut de longueur lg de s).
	 * Ex.:  debut("abcde",10) retourne "abcde"
	 *       debut("abcde", 5) retourne "abcde"
	 *       debut("abcde", 4) retourne "abcd"
	 *       debut("abcde", 1) retourne "a"
	 *       debut("abcde", 0) retourne ""
	 * 
	 * VERSION RECURSIVE : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 * Toutes les methodes de la classe String sont utilisables mais votre code doit etre recursif
	 */
	public static String debutRec(String s, int lg) {
		/*if (lg>=s.length()) {
			return s;
		} else {
			
		}*/
		return ""; 
	}

	/**
	 * Specifications identiques a celles de debutRec mais version iterative.
	 * 
	 * VERSION ITERATIVE : VOTRE CODE NE DOIT PAS ETRE RECURSIF !!!
	 * 
	 * Vous pouvez utiliser les methodes de la classe String a l'exception 
	 * de la fonction subString(int i, int j) 
	 */
	public static String debutIte(String s, int lg) {
		return ""; // A VOUS DE COMPLETER
	}

	/**
	 * 
	 * @param s, une chaine de caracteres. s!=null
	 * @param lg, un entier positif. lg>=0.
	 * @return Si s comporte moins de lg caracteres, retourne s.
	 * Sinon, retourne la chaine formee des lg derniers caracteres de s
	 * (la fin de longueur lg de s).
	 * Ex.:  fin("abcde",10) retourne "abcde"
	 *       fin("abcde", 5) retourne "abcde"
	 *       fin("abcde", 4) retourne "bcde"
	 *       fin("abcde", 1) retourne "e"
	 *       fin("abcde", 0) retourne ""
	 * 
	 * VERSION RECURSIVE : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 * Toutes les methodes de la classe String sont utilisables mais votre code doit etre recursif
	 */
	public static String finRec(String s, int lg) {
		return ""; // A VOUS DE COMPLETER
	}

	/**
	 * Specifications identiques a celles de finRec mais version iterative.
	 * 
	 * VERSION ITERATIVE : VOTRE CODE NE DOIT PAS ETRE RECURSIF !!!
	 * 
	 * Vous pouvez utiliser les methodes de la classe String a l'exception 
	 * de la fonction subString(int i, int j) 
	 */
	public static String finIte(String s, int lg) {
		return ""; // A VOUS DE COMPLETER
	}
}
