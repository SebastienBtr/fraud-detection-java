public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b){
			return a;
			
		} else{
			int  mini;
			int maxi;
			
			if (a>b){
				maxi=a; 
				mini=b;
			}
			else{
				maxi=b;
				mini=a;
			}
			return pgcdRec(mini,(maxi-mini)) ;
		}
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		while (a!=b){
			
			int minimum =Math.min(a,b);
			int maximum =Math.max(a,b);
			
			a = minimum; 
			b = maximum-minimum;
		}
		return a;	
	}
}
