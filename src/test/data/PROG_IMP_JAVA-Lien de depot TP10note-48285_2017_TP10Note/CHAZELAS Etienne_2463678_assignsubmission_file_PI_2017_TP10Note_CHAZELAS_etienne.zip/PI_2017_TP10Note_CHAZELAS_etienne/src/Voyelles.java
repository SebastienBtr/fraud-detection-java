
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		
		if((s.charAt(s.length()-1)="A")||(s.charAt(s.length()-1)="E")||(s.charAt(s.length()-1)="I")||(s.charAt(s.length()-1)="O")||(s.charAt(s.length()-1)="U")||(s.charAt(s.length()-1)="Y")){
			
			return 1;
		}
		else{
			
			return  nbVoyelles( s.substring(0, s.length()-1));
		}

	}	
}
