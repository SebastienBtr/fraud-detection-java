
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if((s.length()==0) && (s.charAt(0)=='A'||s.charAt(0)=='E'||s.charAt(0)=='O'
				||s.charAt(0)=='I'||s.charAt(0)=='U'||s.charAt(0)=='Y')) {
			return 1;
		}else {
			return nbVoyelles(s.substring(1, s.length()));
		}
	}	
}
