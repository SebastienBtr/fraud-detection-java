
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s=="A"||s=="E"||s=="I"||s=="O"||s=="U"||s=="Y") {
			return 1;}
		else if (s.length()==1&&s!="A"&&s!="E"&&s!="I"&&s!="O"&&s!="U"&&s!="Y") {
			return 0;
		}else {
			if (s.substring(0,0)=="A"||s.substring(0,0)=="E"||s.substring(0,0)=="I"||s.substring(0,0)=="O"||s.substring(0,0)=="U"||s.substring(0,0)=="Y") {
				return 1+nbVoyelles(s.substring(1));
			}
			else {
				return 0+nbVoyelles(s.substring(1));
			}
		}
	}	
}
