
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		/*int nb=0;
		if (s.length()<1) {
			return 0;
			
		}
		else {
			if (s.charAt(s.length()-1)=="A" || s.charAt(s.length()-1)=="I" || s.charAt(s.length()-1)=="E" || s.charAt(s.length()-1)=="0" || s.charAt(s.length()-1)=="U" || s.charAt(s.length()-1)=="Y") {
				nb++;
			}
			return nbVoyelles(s.substring(0, s.length()-1));
			}
			
		}*/
		return -1; // A VOUS DE COMPLETER
	}	
}
