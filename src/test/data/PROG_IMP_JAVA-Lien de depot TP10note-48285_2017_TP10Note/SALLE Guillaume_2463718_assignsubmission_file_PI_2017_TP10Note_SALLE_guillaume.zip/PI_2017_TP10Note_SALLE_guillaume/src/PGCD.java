public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return a;
		} else {
			int mini = a<b ? a : b;
			int maxi = a<b ? b : a;
			return pgcdRec(mini,maxi-mini);
		}// A VOUS DE COMPLETER	
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		if (a==b) {
			return a;
		};
		int maxi = a<b ? b : a;
		int k=0;
		int pgcd=maxi;
		while (k<=maxi) {
			if (k%a==0 && k%b==0) {
				pgcd=k;
				k++;
			} else {
				k++;
			}
		}
		return pgcd;
		
		
	}
}
