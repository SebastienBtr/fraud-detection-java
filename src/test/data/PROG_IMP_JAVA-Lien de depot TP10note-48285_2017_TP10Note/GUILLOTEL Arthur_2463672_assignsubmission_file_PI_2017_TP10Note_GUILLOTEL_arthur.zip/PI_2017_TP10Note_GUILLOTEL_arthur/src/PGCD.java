public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */

	public static int pgcdRec(int a, int b) { 
		if (a==0) {return b;}
		else if (b==0) {return a;}
		else if (a==b) {return a;}
		else {return pgcdRec(Math.min(a,b), Math.max(a,b)-Math.min(a,b));
	}
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		if (a==0) {return b;}
		else if (b==0) {return a;}
		else if (a==b) {return a;}
		else {
			while (a!=b) {
				int u=a;
				int v=b;
				a=Math.min(u, v);
				b=Math.max(u, v)-Math.min(u,v);
			}
		}
		if (a==0) {return b;}
		else if (b==0) {return a;}
		else if (a==b) {return a;}
	}
}
