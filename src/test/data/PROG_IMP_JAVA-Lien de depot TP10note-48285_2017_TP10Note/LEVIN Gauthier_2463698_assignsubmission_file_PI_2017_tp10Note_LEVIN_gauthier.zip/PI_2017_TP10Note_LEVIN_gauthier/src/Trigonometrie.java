
public class Trigonometrie {

	public static final double EPSILON = 0.001;

	/**
	 * @param x, un nombre a virgule flottante positif (x>=0)
	 * @return Retourne le sinus de l'angle x
	 * ATTENTION : 
	 * - Votre code doit etre RECURSIF et s'appuyer sur les formules de l'enonce.
	 * - Vous ne pouvez pas utiliser les methodes de la classe Math.
	 * - Vous ne pouvez pas faire appel a d'autres methodes que sinusRec et cosinusRec
	 */
	public static double sinusRec(double x) {
		double s;
		if (x<=EPSILON) {
			s=x;
		}
		else {
			s=2*sinusRec(x/2)*cosinusRec(x/2);
		}
		return s;// A VOUS DE COMPLETER	
	}

	/**
	 * @param x, un nombre a virgule flottante positif (x>=0)
	 * @return Retourne le cosinus de l'angle x
	 * ATTENTION : 
	 * - Votre code doit etre RECURSIF et s'appuyer sur les formules de l'enonce.
	 * - Vous ne pouvez pas utiliser les methodes de la classe Math.
	 * - Vous ne pouvez pas faire appel a d'autres methodes que cosinusRec
	 */
	public static double cosinusRec(double x) {
		double c;
		if (x<=EPSILON) {
			c=1-x*x/2;
		}
		else {
			c=2*cosinusRec(x/2)*cosinusRec(x/2)-1;
		}
		return c;// A VOUS DE COMPLETER	
	}

}
