public class NombresTriangulaires {

	/**
	 * @param n, un entier positif (n>=0)
	 * @return Retourne le nombre triangulaire Tn
	 * Exemple : triangulaire(6) retourne 21.
	 * 
	 * ATTENTION : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 */
	public static int triangulaire(int n){
		int S;
		if (n==0) {
			S=0;
		}
		else {
			S=triangulaire(n-1)+n;
			
		}
		return S;// A VOUS DE COMPLETER	
	}
}
