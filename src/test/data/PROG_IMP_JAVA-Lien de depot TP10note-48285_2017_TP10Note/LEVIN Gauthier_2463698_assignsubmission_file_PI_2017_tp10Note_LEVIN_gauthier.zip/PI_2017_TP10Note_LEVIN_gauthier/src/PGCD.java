public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) {
		int pgcd;
		if (a%b==0) {
			pgcd=b;
		}
		else {
			pgcd=pgcdRec(b,a%b);
		}
		
		return pgcd;// A VOUS DE COMPLETER	
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) {
		int reste=a%b;
		int pgcd=b;
		while (reste!=0) {
			a=b;
			b=reste;
			reste=a%b;
		}
		pgcd=b;
		return pgcd;// A VOUS DE COMPLETER	
	}
}
