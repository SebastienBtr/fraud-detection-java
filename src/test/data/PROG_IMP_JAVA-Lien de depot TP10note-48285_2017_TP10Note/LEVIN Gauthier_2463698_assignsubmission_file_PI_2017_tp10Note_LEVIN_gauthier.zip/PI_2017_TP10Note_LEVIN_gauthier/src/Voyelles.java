
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int n=s.length();
		int nb=0;
		if (n==1 && (s=="A" || s=="E" || s=="I" || s=="O" || s=="U" || s=="Y" )) {
			nb=1;
		}
		else if ((s.charAt(0)=='A' || s.charAt(0)=='E' || s.charAt(0)=='I' || s.charAt(0)=='O' || s.charAt(0)=='U' || s.charAt(0)=='Y')
				|| (s.charAt(n-1)=='A' || s.charAt(n-1)=='E' || s.charAt(n-1)=='I' || s.charAt(n-1)=='O' || s.charAt(n-1)=='U' || s.charAt(n-1)=='Y')) {
			nb=nb+nbVoyelles(s.substring(0, n-1));
		}
		return nb; // A VOUS DE COMPLETER
	}	
}
