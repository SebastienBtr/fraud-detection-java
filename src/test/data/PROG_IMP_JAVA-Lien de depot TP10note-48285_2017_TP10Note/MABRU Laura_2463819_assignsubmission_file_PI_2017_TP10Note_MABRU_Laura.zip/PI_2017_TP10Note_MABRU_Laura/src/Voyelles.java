
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int c=0;
		int i=0;
		int j=1;
		if (s.substring(i,j)=="O"||s.substring(i,j)=="A"||s.substring(i,j)=="E"||s.substring(i,j)=="U"||s.substring(i,j)=="I"||s.substring(i,j)=="Y") {
			c+=1;
		}
		else {
			c+=0;
		}
		nbVoyelles(s.substring(i+1,j+1));
		return c;
	}	
}
