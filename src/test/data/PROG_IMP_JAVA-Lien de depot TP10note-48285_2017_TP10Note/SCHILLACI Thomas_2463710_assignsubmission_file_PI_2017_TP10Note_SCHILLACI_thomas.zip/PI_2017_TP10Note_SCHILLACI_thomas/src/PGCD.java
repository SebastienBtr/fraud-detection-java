public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if(a%b==0) return b;
		return pgcdRec(b,a%b);// A VOUS DE COMPLETER	
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		while(a%b!=0) {
			int tmp=a;
			a=b;
			b=tmp%b;
		}
		return b;
	}
}
