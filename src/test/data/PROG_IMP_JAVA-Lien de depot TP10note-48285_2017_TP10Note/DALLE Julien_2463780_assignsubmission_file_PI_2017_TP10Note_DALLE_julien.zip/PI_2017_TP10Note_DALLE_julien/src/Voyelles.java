
public class Voyelles {
	
	
	
	public static int nbVoyellespas(String s,int i, char[] d) {
		if (i==0) {
			return 0;
		} else {
			int n=0;
			for (int k=0; k<6; k++)	{
				if (s.charAt(i-1)==d[k]) {
					n=1;
				}
			}
			return n+nbVoyellespas(s, i-1,d);
		}
	}
	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		char[] d=new char[6];
		int m=s.length();
		d[0]='A';
		d[1]='E';
		d[2]='I';
		d[3]='O';
		d[4]='U';
		d[5]='Y';
		return nbVoyellespas(s, m,d);
	}	
}
