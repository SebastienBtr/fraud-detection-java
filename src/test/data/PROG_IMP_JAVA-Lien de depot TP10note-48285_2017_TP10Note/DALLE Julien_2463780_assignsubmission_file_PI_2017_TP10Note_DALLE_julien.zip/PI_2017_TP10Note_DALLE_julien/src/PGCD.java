public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return b;
		} else {
			int x=Math.min(a, b);
			return pgcdRec(x,Math.max(a,b)-x);
		}
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		int x=Math.max(a, b);
		int y=Math.min(a, b);
		if ((a==b)||(x%y==0)) {
			return y;
		} else {
			int r=x%y;
			while (r!=0) {
				x=y;
				y=r;
				r=x%y;
			}
			return y;
		}
	}
}
