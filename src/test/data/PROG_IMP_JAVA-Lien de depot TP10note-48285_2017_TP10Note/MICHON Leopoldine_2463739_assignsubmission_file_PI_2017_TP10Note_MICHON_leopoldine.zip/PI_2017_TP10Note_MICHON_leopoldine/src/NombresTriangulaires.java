public class NombresTriangulaires {

	/**
	 * @param n, un entier positif (n>=0)
	 * @return Retourne le nombre triangulaire Tn
	 * Exemple : triangulaire(6) retourne 21.
	 * 
	 * ATTENTION : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 */
	public static int triangulaire(int n){
		int Tn;
		if (n==0) {
			Tn=0;
		}
		else {
			Tn=triangulaire(n-1)+n;
		}
		return Tn;// A VOUS DE COMPLETER	
	}
}
