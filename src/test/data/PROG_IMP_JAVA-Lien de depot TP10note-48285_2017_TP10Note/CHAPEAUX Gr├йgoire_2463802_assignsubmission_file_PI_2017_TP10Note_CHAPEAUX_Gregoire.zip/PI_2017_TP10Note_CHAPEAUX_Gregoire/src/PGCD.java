public class PGCD {
	/**
	 * Min
	 * @param a
	 * @param b
	 * @return min(a,b)
	 */
	public static int min(int a, int b) {
		if (a<=b) {
			return a;
		}
		return b;
	}
	
	/**
	 * Max
	 * @param a
	 * @param b
	 * @return max(a,b)
	 */
	public static int max(int a, int b) {
		if (a>=b) {
			return a;
		}
		return b;
	}
	
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a == b) {
			return a;
		}
		return pgcdRec(min(a,b),max(a,b)-min(a,b));
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		
		int aa = max(a,b); 
		int bb = min(a,b);
		int r = aa%bb;
		
		while (r!=0) {
			aa = bb;
			bb = r;
			r = aa%bb;
		}
		return bb;
	}
}
