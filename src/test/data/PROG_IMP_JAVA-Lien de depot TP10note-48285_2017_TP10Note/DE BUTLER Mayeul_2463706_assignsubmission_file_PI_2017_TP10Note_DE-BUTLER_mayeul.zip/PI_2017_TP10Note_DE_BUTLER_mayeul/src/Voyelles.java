
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length ()==0) {
			return 0;
		}
		else {
			return voyelle(s,0) + nbVoyelles(s.substring(1, s.length()));
		}
		
	}	
	
	public static int voyelle(String s, int i) {
		String Voyelle = "AEIOUY";
		for (int k =0 ; k< Voyelle.length();k++) {
			if (s.charAt(i) == Voyelle.charAt(k) ){
				return 1;
			}
		}
		return 0;
		
	}
}
