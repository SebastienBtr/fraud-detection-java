public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		int r = a%b;
		if (r ==0) {
			return b;
		}
		else {
			return pgcdRec(b,r);
		}	
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		if ( a==b) {
			return a;
		}
		else {
			 int r = a%b;
			 if (r==0) {
				 return b;
			 }
			while (r!= 0) {
				r = b%r;
				}
			return b;
	
		}
	}
}