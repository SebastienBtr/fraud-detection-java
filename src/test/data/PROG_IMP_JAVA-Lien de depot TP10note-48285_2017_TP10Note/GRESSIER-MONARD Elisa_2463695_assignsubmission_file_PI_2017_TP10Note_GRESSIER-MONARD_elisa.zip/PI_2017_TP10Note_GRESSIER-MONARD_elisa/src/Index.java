public class Index {

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus grand i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
/*		boolean trouve = false;
		for (int i=0; i<pos; i++){
			if (t[i] == valeur)
					trouve = true;
					
		}
		if (trouve = false)
			return(-1);
		else{
			int[] k = new int[t.length-1];
			for (int j = 1; j<t.length; j++){
				k [j] = t[j];
			return lastIndexOf(t, pos, valeur);}}
	} */

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus petit i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int firstIndexOf(int[] t, int pos, int valeur) {
		return -1;// A VOUS DE COMPLETER	
	}
}
