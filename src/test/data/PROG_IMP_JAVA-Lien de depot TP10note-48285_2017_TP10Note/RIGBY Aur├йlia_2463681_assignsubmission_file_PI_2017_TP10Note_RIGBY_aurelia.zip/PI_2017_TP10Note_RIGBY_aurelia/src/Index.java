public class Index {

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus grand i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int lastIndexOf(int[] t, int pos, int valeur) {
		/*if (lastIndexOf(t,pos,valeur)!=valeur) {
			return -1;
		}
		else {
			if (lastIndexOf(t,pos,valeur)>=lastIndexOf(t,pos-1,valeur)) {
				return pos;
		}
		}*/	
		return 0;
	}

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus petit i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int firstIndexOf(int[] t, int pos, int valeur) {
		return -1;// A VOUS DE COMPLETER	
	}
}
