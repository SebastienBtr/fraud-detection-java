
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int t=s.length();
		if (t==0) {
			return 0;
			}
		else {
			if ((s.charAt(t-1)=='A') || (s.charAt(t-1)=='E') || (s.charAt(t-1)=='I') || (s.charAt(t-1)=='O') || (s.charAt(t-1)=='U') || (s.charAt(t-1)=='Y') ) {
				return nbVoyelles(s.substring(0, t-1))+1;
				}
			else {
				return nbVoyelles(s.substring(0, t-1));
			}
		}
	}	
}
