public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return a;
		} else {
			int min;
			int max;
			if (a>b) {
				min=b;
				max=a;
			} else {
				min=a;
				max=b;
			}
			return pgcdRec(min,(max-min));
		}
		
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		while (a!=b) {
			int min = Math.min(a, b); 
			int max = Math.max(a, b); 
			a = min;
			b = max-min;
			}
			return a;
	}
}
