
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
/**	public static int Voyelles(String s) {
		int res=0;
		if (s.charAt(1)=='A' ||s.charAt(1)=='E'||s.charAt(1)=='I'||s.charAt(1)=='O'||s.charAt(1)=='U'||s.charAt(1)=='Y') {
			=1;	
		}
		return res;
	} 
		
	
	public static int nbVoyelles(String s) {
		int res=0;
		int n=s.length();
		if(n==0) {
			return 0;
		} else {
			return res+Voyelles(s)+nbVoyelles(s.substring(0,n-1));
		}
			 // A VOUS DE COMPLETER
	}*/	
}
