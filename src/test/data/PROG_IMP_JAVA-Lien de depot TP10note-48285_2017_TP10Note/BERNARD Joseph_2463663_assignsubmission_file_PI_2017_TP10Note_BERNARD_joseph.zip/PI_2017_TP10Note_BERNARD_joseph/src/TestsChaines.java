

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class TestsChaines implements ClipboardOwner {
	public static int DELAI = 250; // Temps d'attente entre les affichages lors d'une levee d'exception


	public static Class getClass(String nomClasse) {
		Class t;
		try  {
			t = Class.forName(nomClasse);
			return t;
		}  catch (ClassNotFoundException e) {
			return null;
		}
	}

	public static boolean isAbstract(Class c) {
		return Modifier.isAbstract(c.getModifiers());
	}

	public static boolean implementsInterface(Class c, Class interfac) {
		List<Class> interfaces = Arrays.asList( c.getInterfaces() );
		return interfaces.contains(interfac);
	}

	public static boolean extendsClass(Class c, Class superClasse) {
		return (c.getSuperclass().equals(superClasse));
	}

	public static Class[] getArgs(String[] argsClass) {
		if (argsClass==null) {
			return null;
		}
		Class[] args = new Class[ argsClass.length];
		for (int i=0; i<argsClass.length; i++) {
			if (argsClass[i].equals("int")) {
				args[i]=int.class;
			} else if (argsClass[i].equals("String")) {
				args[i]=String.class;
			} else {
				args[i]=getClass(argsClass[i]);
			}
		}
		return args;

	}
	public static Constructor getConstructor(Class c, Class[] args) {
		Constructor cons=null;
		try {
			//System.out.println(Arrays.toString(c.getConstructors()));
			cons= c.getConstructor(args);
		} catch(Exception e) {};
		return cons;
	}
	public static Constructor getConstructor(Class c, String[] argsClass) {
		return getConstructor( c, getArgs(argsClass));
	}

	public static Method getMethode(Class c, String methode, Class[] args) {
		try {
			return c.getMethod(methode, args);
		} catch (Exception nonCapturee) {
			return null;
		}
	}
	public static Method getMethode(Class c, String methode,String[] args) {
		return getMethode(c, methode,  getArgs(args));
	}
	public static String remove(String fic, String mot) {
		String res = fic; 
		while (res.contains(mot)) {
			res=res.replace(mot,"");
		}
		return res;
	}
	public static String removeStartingChars(String s, char c) {
		String res= s;
		while (res!=null && res.length()>0 && res.charAt(0)==c) {
			res=res.substring(1);
		}
		return res;
	}
	public static String startingId(String s) {
		String res= s;
		String delimiters = " \t,;(){}";
		while (s.length()>0 && delimiters.contains(""+s.charAt(0))) {
			s=s.substring(1);
		}
		int end=0;

		while (res!=null && res.length()>0 && end<res.length() && !delimiters.contains(""+res.charAt(end))) {
			end++;
		}
		return res.substring(0, end);
	}
	public static String withoutStartingId(String s) {
		String res= s;
		String delimiters = " \t,;(){}"+(char)10+(char)13;
		while (res.length()>0 && delimiters.contains(""+res.charAt(0))) {
			res=res.substring(1);
		}
		int end=0;
		while (res!=null && res.length()>0 && end<res.length() && !delimiters.contains(""+res.charAt(end))) {
			end++;
		}
		return res.substring(end, res.length());
	}
	public static String constructeurNomFic(String nomfic, String nomClasse, String[] args) {
		String fic = sansCommentaires(nomfic);
		return constructeur(fic, nomClasse, args);
	}
	public static String sansEspacesAvantParentheses(String s) {
		String res = s;
		while (res.indexOf(" (")>=0) {
			res = res.replace(" (","(");
		}
		while (res.indexOf("\t(")>=0) {
			res = res.replace("\t(","(");
		}
		return res;
	}
	public static String constructeur(String fic, String nomClasse, String[] args) {
		fic = sansEspacesAvantParentheses(fic);
		int index = fic.indexOf(nomClasse+"(");
		if (index<0) {
			return "";
		} else {
			//System.out.println("index = "+index);
			fic = fic.substring(index);
			fic = withoutStartingId(fic);
			if (fic.length()>0) fic = fic.substring(1);
			//System.out.println(" trouve : "+fic);
			//int ip=index+1;
			int p = 0;
			while (//ip<fic.length() &&
					p<args.length 
					&& fic.charAt(0)!=')') {
				//fic = removeStartingChars(fic, ' ');
				//fic = removeStartingChars(fic, '\t');
				if (startingId(fic).equals(args[p])) {
					//System.out.println("avant="+fic);
					//System.out.println("un seul = "+withoutStartingId(fic));
					fic = withoutStartingId( withoutStartingId(fic));
					//System.out.println("apres="+fic);
					p++;
				} else {
					//	System.out.println("aie... fic="+fic+"\n ne commence pas par "+args[p]);
					return constructeur(fic, nomClasse, args);
				}
			}
			//System.out.println("FFic="+fic);
			fic =removeStartingChars(fic,' ');
			fic = removeStartingChars(fic, '\t');
			//System.out.println(" trouve : "+fic);System.exit(0);
			if (p<args.length || fic.length()==0 || fic.charAt(0)!=')') {
				//System.out.println(" trouve : "+fic);//System.exit(0);
				return  constructeur(fic, nomClasse, args);
			}
			int i= 0;//index+1;
			while (i<fic.length() && fic.charAt(i)!='{') {
				i++;
			}
			i++;
			int nbOuvertes=1;
			while (nbOuvertes>0 && i<fic.length()) {
				if (fic.charAt(i)=='{') {
					nbOuvertes++;
				}
				if (fic.charAt(i)=='}') {
					nbOuvertes--;
				}
				i++;
			}
			if (i<fic.length()) {
				//return fic.substring(index, i);
				return fic.substring(fic.indexOf("{"), i);
			} else {
				return "";
			}
		}
	}
	public static String methode(String fic, String nomMethode) {
		//System.out.println("fic recu par methode() : "+fic);
		int index = fic.indexOf(nomMethode);
		if (index<0) {
			return "";
		} else {
			int i= index+1;
			while (i<fic.length() && fic.charAt(i)!='{') {
				i++;
			}
			i++;
			int nbOuvertes=1;
			while (nbOuvertes>0 && i<fic.length()) {
				if (fic.charAt(i)=='{') {
					nbOuvertes++;
				}
				if (fic.charAt(i)=='}') {
					nbOuvertes--;
				}
				i++;
			}
			if (i<fic.length()) {
				//	System.out.println("fic renvoye par methode() : "+fic.substring(index, i));
				return fic.substring(index, i);
			} else {
				return "";
			}
		}
	}
	public static List<String> lignesSansCommentaires(String fic) {
		List<String> l=new ArrayList<String>();
		List<String> m=new ArrayList<String>();
		//String res="";
		try {
			FileReader fr = new FileReader(fic);
			BufferedReader br = new BufferedReader( fr );
			String s;
			do {
				s = br.readLine();
				if (s!=null) {
					l.add(s);
				}
			} while (s!=null);

			//Iterator<String> it = br.lines().iterator();

			//String s;
			//while (it.hasNext()) {
			//	s =it.next();
			/*				int index = s.indexOf("//");
				if (index>=0) { 
					s=s.substring(0, index);
				}
			 */			//	l.add(s);
			//}

			br.close();
		} catch (Exception e) {
			System.out.println(e);
		}	
		int i=0; 

		while (i<l.size()) {
			int debut = l.get(i).indexOf("/*");
			int fin = l.get(i).indexOf("*/");
			if (debut>=0) {
				if (fin>=0) {
					m.add(l.get(i).substring(0, debut)+""+ l.get(i).substring(fin+2));
				} else {
					m.add(l.get(i).substring(0, debut));
					i++;
					while (i<l.size() && l.get(i).indexOf("*/")<0) {
						i++;
					}
					fin = l.get(i).indexOf("*/");
					m.add(l.get(i).substring(fin+2));
				}
			} else if ( l.get(i).indexOf("//")>=0) {
				m.add(l.get(i).substring(0, l.get(i).indexOf("//")));
			}	else {
				m.add(l.get(i));
			}
			i++;
		}
		//for (String r : m) {
		//	res=res+r+"\n";
		//}
		return m;//res;
	}
	public static String sansCommentaires(String fic) {
		return reunirLignes( lignesSansCommentaires(fic));
	}
	public static String reunirLignes(List<String> lignes) {
		String res="";
		for (String r : lignes) {
			res=res+r+"\n";
		}
		return res;
	}
	public static int nbDeclaredFields(Class c) {
		return c.getDeclaredFields().length;
	}
	public static int nbDeclaredFieldsOfType(Class c, Class typ) {
		Field[] fields = c.getDeclaredFields();
		int nb=0;
		for (Field f : fields) {
			if (f.getType().equals(typ)) {
				nb++;
			}
		}
		return nb;
	}

	public static boolean fieldsDeclaredPrivate(//String file,
			Class c) {
		//	boolean res=true;
		//	List<String> lignes = lignesSansCommentaires(file);
		Field[] fields = c.getDeclaredFields();
		for (Field f : fields) {
			if (!Modifier.isPrivate(f.getModifiers())) {
				return false;
			}
		}
		return true;
	}
	/*	public static boolean fieldsDeclaredPrivate(String file, Class c) {
		boolean res=true;
		List<String> lignes = lignesSansCommentaires(file);
		Field[] fields = c.getDeclaredFields();
		for (Field f : fields) {
			int lig =0;
			while (lig<lignes.size() && !lignes.get(lig).contains(f.getName())) {
				lig++;
			}
			if (lig<lignes.size() && !lignes.get(lig).contains("private")) {
				res=false;
			}
		}
		return res;
	}*/
	public static boolean hasFieldOfType(Class c, Class type ) {
		boolean res=true;
		Field[] fields = c.getDeclaredFields();
		for (Field f : fields) {
			if (f.getType().equals(type)) {
				return true;
			} 
		}
		return false;
	}

	public static List<String> getMots(String s) {
		List<String> l = new ArrayList<String>();
		String delimiteurs = " ,.;:/?%*+=-<>\\_()[]{}&"+(char)13+"|"+(char)10+"\t";
		String mot="";
		for (int i=0; i<s.length(); i++) {
			if (delimiteurs.contains(""+s.charAt(i))) {
				if (!mot.equals("")) {
					l.add(mot);
					mot="";
				}
			} else {
				mot=mot+s.charAt(i);
			}
		}
		return l;

	}

	public static boolean estUneVariableLocale(String file, Class c, String methode, String var) {
		String met = methode(sansCommentaires(file),methode);
		List<String> mots = getMots(met);
		int pos = mots.indexOf(var);
		if (pos>0) {
			String[] primitifs= {"int", "char", "boolean", "float", "long", "double"};
			List<String> lprimitifs = Arrays.asList(primitifs);
			if (lprimitifs.contains(mots.get(pos-1))) {
				return true;
			} else {
				//System.out.println(c.getPackage().getName());
				return getClass(mots.get(pos-1))!=null ||  getClass(c.getPackage().getName()+"."+mots.get(pos-1))!=null;
			}
		} else {
			return false;
		}
	}
	public static boolean respecteDeveloppementEnCouche(String file, Class c, String methode) {
		String met = methode(sansCommentaires(file),methode);

		//System.out.println(" ---- avant retrait des methodes : "+met);
		Method[] methodes = c.getDeclaredMethods();
		String sans = met;
		for (Method m : methodes) {
			sans = remove(sans, m.getName());
		}
		//System.out.println(" ---- apres retrait des methodes : "+sans);
		boolean couche = true;
		Field[] fields = c.getDeclaredFields();

		int i=0;
		while (couche && i<fields.length) {
			//System.out.println("field "+fields[i].getName()+"\n"+sans);
			//System.out.println("mots :"+getMots(sans));
			if (getMots(sans).contains(fields[i].getName())){// && sans.contains(fields[i].getName()+".")) {
				if (!estUneVariableLocale(file, c, methode,fields[i].getName() )) {
					couche=false;
				}
				//System.out.println("field "+fields[i].getName()+" trouve");
			}
			i++;
		}
		return couche;
	}

	public static void afficheThrowable( Throwable e, String test) {
		System.out.println(">>>>>> AIE..."+test+" lance "+e.toString());
		try {Thread.sleep(DELAI);} catch (Exception ex) {};
		e.printStackTrace();
		try {Thread.sleep(DELAI);} catch (Exception ex) {};
		if (e.getCause()!=null) { 
			System.out.println("Cause :");
			e.getCause().printStackTrace();
		}
		try {Thread.sleep(DELAI);} catch (Exception ex) {};
		System.out.println("<<<<<<<<<<<<<<<<<<");
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////START
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int testDebutRec() {
		int note=100;
		String[] jeux = {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
		"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa",
		"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"};

		String[][] resDeb= {{"", 
				"a", "ab", "abc", 
				"abcd", "abcde", "abcdef", 
				"abcdefg", "abcdefgh", "abcdefghi", 
				"abcdefghij", "abcdefghijk", "abcdefghijkl", 
				"abcdefghijklm", "abcdefghijklmn", "abcdefghijklmno", 
				"abcdefghijklmnop", "abcdefghijklmnopq", "abcdefghijklmnopqr", 
				"abcdefghijklmnopqrs", "abcdefghijklmnopqrst", "abcdefghijklmnopqrstu", 
				"abcdefghijklmnopqrstuv", "abcdefghijklmnopqrstuvw", "abcdefghijklmnopqrstuvwx", 
				"abcdefghijklmnopqrstuvwxy", "abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxyzA", 
				"abcdefghijklmnopqrstuvwxyzAB", "abcdefghijklmnopqrstuvwxyzABC", "abcdefghijklmnopqrstuvwxyzABCD", 
				"abcdefghijklmnopqrstuvwxyzABCDE", "abcdefghijklmnopqrstuvwxyzABCDEF", "abcdefghijklmnopqrstuvwxyzABCDEFG", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGH", "abcdefghijklmnopqrstuvwxyzABCDEFGHI", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJ", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJK", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKL", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMN", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNO", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQR", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRS", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRST", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUV", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVW", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWX", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"}
		,{
				"", 
				"f", "ff", "ffd", 
				"ffdf", "ffdfk", "ffdfkl", 
				"ffdfklf", "ffdfklfj", "ffdfklfjk", 
				"ffdfklfjkl", "ffdfklfjkls", "ffdfklfjklsf", 
				"ffdfklfjklsfj", "ffdfklfjklsfjl", "ffdfklfjklsfjlj", 
				"ffdfklfjklsfjljk", "ffdfklfjklsfjljkl", "ffdfklfjklsfjljkle", 
				"ffdfklfjklsfjljklej", "ffdfklfjklsfjljklejz", "ffdfklfjklsfjljklejzz", 
				"ffdfklfjklsfjljklejzzr", "ffdfklfjklsfjljklejzzri", "ffdfklfjklsfjljklejzzriz", 
				"ffdfklfjklsfjljklejzzrizo", "ffdfklfjklsfjljklejzzrizoj", "ffdfklfjklsfjljklejzzrizojn", 
				"ffdfklfjklsfjljklejzzrizojnj", "ffdfklfjklsfjljklejzzrizojnjn", "ffdfklfjklsfjljklejzzrizojnjnk", 
				"ffdfklfjklsfjljklejzzrizojnjnkn", "ffdfklfjklsfjljklejzzrizojnjnknj", "ffdfklfjklsfjljklejzzrizojnjnknjn", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnk", "ffdfklfjklsfjljklejzzrizojnjnknjnkj", "ffdfklfjklsfjljklejzzrizojnjnknjnkjq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqn", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqna", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaza", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazl", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxm", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzl", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzld", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzo", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzos", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzosz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzo", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
		},{
				"", 
				"a", "aa", "aaa", 
				"aaas", "aaask", "aaaskj", 
				"aaaskjn", "aaaskjnx", "aaaskjnxa", 
				"aaaskjnxad", "aaaskjnxadk", "aaaskjnxadkd", 
				"aaaskjnxadkdq", "aaaskjnxadkdqz", "aaaskjnxadkdqzn", 
				"aaaskjnxadkdqznd", "aaaskjnxadkdqzndl", "aaaskjnxadkdqzndlx", 
				"aaaskjnxadkdqzndlxd", "aaaskjnxadkdqzndlxdz", "aaaskjnxadkdqzndlxdzd", 
				"aaaskjnxadkdqzndlxdzdz", "aaaskjnxadkdqzndlxdzdze", "aaaskjnxadkdqzndlxdzdzex", 
				"aaaskjnxadkdqzndlxdzdzexd", "aaaskjnxadkdqzndlxdzdzexdd", "aaaskjnxadkdqzndlxdzdzexddd", 
				"aaaskjnxadkdqzndlxdzdzexddde", "aaaskjnxadkdqzndlxdzdzexddded", "aaaskjnxadkdqzndlxdzdzexdddedx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxf", "aaaskjnxadkdqzndlxdzdzexdddedxfq", "aaaskjnxadkdqzndlxdzdzexdddedxfqg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxe", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxege", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeger", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegerg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgre", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgreg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxz", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"		
		}};
		String[][] resFin= {
				{
					"", 
					"0", "90", "890", 
					"7890", "67890", "567890", 
					"4567890", "34567890", "234567890", 
					"1234567890", "Z1234567890", "YZ1234567890", 
					"XYZ1234567890", "WXYZ1234567890", "VWXYZ1234567890", 
					"UVWXYZ1234567890", "TUVWXYZ1234567890", "STUVWXYZ1234567890", 
					"RSTUVWXYZ1234567890", "QRSTUVWXYZ1234567890", "PQRSTUVWXYZ1234567890", 
					"OPQRSTUVWXYZ1234567890", "NOPQRSTUVWXYZ1234567890", "MNOPQRSTUVWXYZ1234567890", 
					"LMNOPQRSTUVWXYZ1234567890", "KLMNOPQRSTUVWXYZ1234567890", "JKLMNOPQRSTUVWXYZ1234567890", 
					"IJKLMNOPQRSTUVWXYZ1234567890", "HIJKLMNOPQRSTUVWXYZ1234567890", "GHIJKLMNOPQRSTUVWXYZ1234567890", 
					"FGHIJKLMNOPQRSTUVWXYZ1234567890", "EFGHIJKLMNOPQRSTUVWXYZ1234567890", "DEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"CDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "BCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"zABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "yzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "xyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"wxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "vwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "uvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"tuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "stuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "rstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"qrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "pqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"nopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "mnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "lmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"klmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"hijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "fghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"efghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "defghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "cdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"bcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
				}, {
					"", 
					"a", "oa", "zoa", 
					"zzoa", "dzzoa", "zdzzoa", 
					"dzdzzoa", "zdzdzzoa", "xzdzdzzoa", 
					"zxzdzdzzoa", "szxzdzdzzoa", "oszxzdzdzzoa", 
					"zoszxzdzdzzoa", "dzoszxzdzdzzoa", "ldzoszxzdzdzzoa", 
					"zldzoszxzdzdzzoa", "mzldzoszxzdzdzzoa", "xmzldzoszxzdzdzzoa", 
					"lxmzldzoszxzdzdzzoa", "zlxmzldzoszxzdzdzzoa", "azlxmzldzoszxzdzdzzoa", 
					"zazlxmzldzoszxzdzdzzoa", "azazlxmzldzoszxzdzdzzoa", "qazazlxmzldzoszxzdzdzzoa", 
					"aqazazlxmzldzoszxzdzdzzoa", "naqazazlxmzldzoszxzdzdzzoa", "qnaqazazlxmzldzoszxzdzdzzoa", 
					"jqnaqazazlxmzldzoszxzdzdzzoa", "kjqnaqazazlxmzldzoszxzdzdzzoa", "nkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnkjqnaqazazlxmzldzoszxzdzdzzoa", "knjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"nknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"izojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "rizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"zzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"lejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"sfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"klfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "dfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"fdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
				}, {
					"", 
					"h", "hh", "hhh", 
					"xhhh", "gxhhh", "zgxhhh", 
					"xzgxhhh", "rxzgxhhh", "grxzgxhhh", 
					"rgrxzgxhhh", "grgrxzgxhhh", "xgrgrxzgxhhh", 
					"gxgrgrxzgxhhh", "egxgrgrxzgxhhh", "regxgrgrxzgxhhh", 
					"gregxgrgrxzgxhhh", "rgregxgrgrxzgxhhh", "rrgregxgrgrxzgxhhh", 
					"grrgregxgrgrxzgxhhh", "rgrrgregxgrgrxzgxhhh", "ergrrgregxgrgrxzgxhhh", 
					"gergrrgregxgrgrxzgxhhh", "egergrrgregxgrgrxzgxhhh", "xegergrrgregxgrgrxzgxhhh", 
					"gxegergrrgregxgrgrxzgxhhh", "qgxegergrrgregxgrgrxzgxhhh", "xqgxegergrrgregxgrgrxzgxhhh", 
					"gxqgxegergrrgregxgrgrxzgxhhh", "qgxqgxegergrrgregxgrgrxzgxhhh", "gqgxqgxegergrrgregxgrgrxzgxhhh", 
					"qgqgxqgxegergrrgregxgrgrxzgxhhh", "fqgqgxqgxegergrrgregxgrgrxzgxhhh", "xfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"dxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "edxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"ddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"exdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "zexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"lxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "ndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "qzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "adkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"xadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "nxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "jnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "skjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "askjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"	
				}
		};
		System.out.println("Test de debutRec :");
		/*
		for (int i=0; i<=s3.length()+3; i++) {
			System.out.print("\""+Chaines.finRec(s3, i)+"\", ");
			if (i%3==0) {
				System.out.println();
			}
		}*/
		int k=0;
		int jeu=0;
		boolean ok=true;
		while (jeu<resDeb.length && ok) {
			
		k=0;
		while (k<resDeb[jeu].length && ok) {
			ok = (Chaines.debutRec(jeux[jeu], k).equals(resDeb[jeu][k]));
			if (!ok) {
				System.out.println("   Aie... debutRec(\""+jeux[jeu]+"\", "+k+") retourne \""+Chaines.debutRec(jeux[jeu], k)+"\" au lieu de \""+resDeb[jeu][k]+"\"");
				note=0;
			}
			k++;
		}
		jeu++;
		}
		if (note>0) {
			String met = methode(sansCommentaires("src"+File.separator+"Chaines.java"),"debutRec").substring(2);
			//System.out.println(met);
			if (!met.contains("debutRec")) {
				System.out.println("   Aie... votre implementation de debutRec doit etre RECURSIVE");
				note=0;
			}
		} 
		
		
		if (note==100) {		
			System.out.println("  Ok. Votre code passe le test");
		}
		return note;
	}
	
	
	
	

	public static int testFinRec() {
		int note=100;
		String[] jeux = {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
		"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa",
		"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"};

		String[][] resDeb= {{"", 
				"a", "ab", "abc", 
				"abcd", "abcde", "abcdef", 
				"abcdefg", "abcdefgh", "abcdefghi", 
				"abcdefghij", "abcdefghijk", "abcdefghijkl", 
				"abcdefghijklm", "abcdefghijklmn", "abcdefghijklmno", 
				"abcdefghijklmnop", "abcdefghijklmnopq", "abcdefghijklmnopqr", 
				"abcdefghijklmnopqrs", "abcdefghijklmnopqrst", "abcdefghijklmnopqrstu", 
				"abcdefghijklmnopqrstuv", "abcdefghijklmnopqrstuvw", "abcdefghijklmnopqrstuvwx", 
				"abcdefghijklmnopqrstuvwxy", "abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxyzA", 
				"abcdefghijklmnopqrstuvwxyzAB", "abcdefghijklmnopqrstuvwxyzABC", "abcdefghijklmnopqrstuvwxyzABCD", 
				"abcdefghijklmnopqrstuvwxyzABCDE", "abcdefghijklmnopqrstuvwxyzABCDEF", "abcdefghijklmnopqrstuvwxyzABCDEFG", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGH", "abcdefghijklmnopqrstuvwxyzABCDEFGHI", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJ", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJK", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKL", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMN", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNO", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQR", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRS", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRST", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUV", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVW", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWX", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"}
		,{
				"", 
				"f", "ff", "ffd", 
				"ffdf", "ffdfk", "ffdfkl", 
				"ffdfklf", "ffdfklfj", "ffdfklfjk", 
				"ffdfklfjkl", "ffdfklfjkls", "ffdfklfjklsf", 
				"ffdfklfjklsfj", "ffdfklfjklsfjl", "ffdfklfjklsfjlj", 
				"ffdfklfjklsfjljk", "ffdfklfjklsfjljkl", "ffdfklfjklsfjljkle", 
				"ffdfklfjklsfjljklej", "ffdfklfjklsfjljklejz", "ffdfklfjklsfjljklejzz", 
				"ffdfklfjklsfjljklejzzr", "ffdfklfjklsfjljklejzzri", "ffdfklfjklsfjljklejzzriz", 
				"ffdfklfjklsfjljklejzzrizo", "ffdfklfjklsfjljklejzzrizoj", "ffdfklfjklsfjljklejzzrizojn", 
				"ffdfklfjklsfjljklejzzrizojnj", "ffdfklfjklsfjljklejzzrizojnjn", "ffdfklfjklsfjljklejzzrizojnjnk", 
				"ffdfklfjklsfjljklejzzrizojnjnkn", "ffdfklfjklsfjljklejzzrizojnjnknj", "ffdfklfjklsfjljklejzzrizojnjnknjn", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnk", "ffdfklfjklsfjljklejzzrizojnjnknjnkj", "ffdfklfjklsfjljklejzzrizojnjnknjnkjq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqn", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqna", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaza", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazl", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxm", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzl", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzld", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzo", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzos", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzosz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzo", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
		},{
				"", 
				"a", "aa", "aaa", 
				"aaas", "aaask", "aaaskj", 
				"aaaskjn", "aaaskjnx", "aaaskjnxa", 
				"aaaskjnxad", "aaaskjnxadk", "aaaskjnxadkd", 
				"aaaskjnxadkdq", "aaaskjnxadkdqz", "aaaskjnxadkdqzn", 
				"aaaskjnxadkdqznd", "aaaskjnxadkdqzndl", "aaaskjnxadkdqzndlx", 
				"aaaskjnxadkdqzndlxd", "aaaskjnxadkdqzndlxdz", "aaaskjnxadkdqzndlxdzd", 
				"aaaskjnxadkdqzndlxdzdz", "aaaskjnxadkdqzndlxdzdze", "aaaskjnxadkdqzndlxdzdzex", 
				"aaaskjnxadkdqzndlxdzdzexd", "aaaskjnxadkdqzndlxdzdzexdd", "aaaskjnxadkdqzndlxdzdzexddd", 
				"aaaskjnxadkdqzndlxdzdzexddde", "aaaskjnxadkdqzndlxdzdzexddded", "aaaskjnxadkdqzndlxdzdzexdddedx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxf", "aaaskjnxadkdqzndlxdzdzexdddedxfq", "aaaskjnxadkdqzndlxdzdzexdddedxfqg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxe", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxege", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeger", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegerg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgre", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgreg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxz", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"		
		}};
		String[][] resFin= {
				{
					"", 
					"0", "90", "890", 
					"7890", "67890", "567890", 
					"4567890", "34567890", "234567890", 
					"1234567890", "Z1234567890", "YZ1234567890", 
					"XYZ1234567890", "WXYZ1234567890", "VWXYZ1234567890", 
					"UVWXYZ1234567890", "TUVWXYZ1234567890", "STUVWXYZ1234567890", 
					"RSTUVWXYZ1234567890", "QRSTUVWXYZ1234567890", "PQRSTUVWXYZ1234567890", 
					"OPQRSTUVWXYZ1234567890", "NOPQRSTUVWXYZ1234567890", "MNOPQRSTUVWXYZ1234567890", 
					"LMNOPQRSTUVWXYZ1234567890", "KLMNOPQRSTUVWXYZ1234567890", "JKLMNOPQRSTUVWXYZ1234567890", 
					"IJKLMNOPQRSTUVWXYZ1234567890", "HIJKLMNOPQRSTUVWXYZ1234567890", "GHIJKLMNOPQRSTUVWXYZ1234567890", 
					"FGHIJKLMNOPQRSTUVWXYZ1234567890", "EFGHIJKLMNOPQRSTUVWXYZ1234567890", "DEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"CDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "BCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"zABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "yzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "xyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"wxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "vwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "uvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"tuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "stuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "rstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"qrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "pqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"nopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "mnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "lmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"klmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"hijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "fghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"efghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "defghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "cdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"bcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
				}, {
					"", 
					"a", "oa", "zoa", 
					"zzoa", "dzzoa", "zdzzoa", 
					"dzdzzoa", "zdzdzzoa", "xzdzdzzoa", 
					"zxzdzdzzoa", "szxzdzdzzoa", "oszxzdzdzzoa", 
					"zoszxzdzdzzoa", "dzoszxzdzdzzoa", "ldzoszxzdzdzzoa", 
					"zldzoszxzdzdzzoa", "mzldzoszxzdzdzzoa", "xmzldzoszxzdzdzzoa", 
					"lxmzldzoszxzdzdzzoa", "zlxmzldzoszxzdzdzzoa", "azlxmzldzoszxzdzdzzoa", 
					"zazlxmzldzoszxzdzdzzoa", "azazlxmzldzoszxzdzdzzoa", "qazazlxmzldzoszxzdzdzzoa", 
					"aqazazlxmzldzoszxzdzdzzoa", "naqazazlxmzldzoszxzdzdzzoa", "qnaqazazlxmzldzoszxzdzdzzoa", 
					"jqnaqazazlxmzldzoszxzdzdzzoa", "kjqnaqazazlxmzldzoszxzdzdzzoa", "nkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnkjqnaqazazlxmzldzoszxzdzdzzoa", "knjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"nknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"izojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "rizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"zzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"lejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"sfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"klfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "dfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"fdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
				}, {
					"", 
					"h", "hh", "hhh", 
					"xhhh", "gxhhh", "zgxhhh", 
					"xzgxhhh", "rxzgxhhh", "grxzgxhhh", 
					"rgrxzgxhhh", "grgrxzgxhhh", "xgrgrxzgxhhh", 
					"gxgrgrxzgxhhh", "egxgrgrxzgxhhh", "regxgrgrxzgxhhh", 
					"gregxgrgrxzgxhhh", "rgregxgrgrxzgxhhh", "rrgregxgrgrxzgxhhh", 
					"grrgregxgrgrxzgxhhh", "rgrrgregxgrgrxzgxhhh", "ergrrgregxgrgrxzgxhhh", 
					"gergrrgregxgrgrxzgxhhh", "egergrrgregxgrgrxzgxhhh", "xegergrrgregxgrgrxzgxhhh", 
					"gxegergrrgregxgrgrxzgxhhh", "qgxegergrrgregxgrgrxzgxhhh", "xqgxegergrrgregxgrgrxzgxhhh", 
					"gxqgxegergrrgregxgrgrxzgxhhh", "qgxqgxegergrrgregxgrgrxzgxhhh", "gqgxqgxegergrrgregxgrgrxzgxhhh", 
					"qgqgxqgxegergrrgregxgrgrxzgxhhh", "fqgqgxqgxegergrrgregxgrgrxzgxhhh", "xfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"dxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "edxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"ddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"exdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "zexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"lxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "ndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "qzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "adkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"xadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "nxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "jnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "skjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "askjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"	
				}
		};
		System.out.println("\nTest de finRec :");
		/*
		for (int i=0; i<=s3.length()+3; i++) {
			System.out.print("\""+Chaines.finRec(s3, i)+"\", ");
			if (i%3==0) {
				System.out.println();
			}
		}*/
		int k=0;
		int jeu=0;
		boolean ok=true;
		while (jeu<resFin.length && ok) {
			
		k=0;
		while (k<resFin[jeu].length && ok) {
			ok = (Chaines.finRec(jeux[jeu], k).equals(resFin[jeu][k]));
			if (!ok) {
				System.out.println("   Aie... finRec(\""+jeux[jeu]+"\", "+k+") retourne \""+Chaines.finRec(jeux[jeu], k)+"\" au lieu de \""+resFin[jeu][k]+"\"");
				note=0;
			}
			k++;
		}
		jeu++;
		}
		if (note>0) {
			String met = methode(sansCommentaires("src"+File.separator+"Chaines.java"),"finRec").substring(2);
			//System.out.println(met);
			if (!met.contains("finRec")) {
				System.out.println("   Aie... votre implementation de finRec doit etre RECURSIVE");
				note=0;
			}
		} 
		
		
		if (note==100) {		
			System.out.println("  Ok. Votre code passe le test");
		}
		return note;
	}
	
	public static int testDebutIte() {
		int note=100;
		String[] jeux = {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
		"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa",
		"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"};

		String[][] resDeb= {{"", 
				"a", "ab", "abc", 
				"abcd", "abcde", "abcdef", 
				"abcdefg", "abcdefgh", "abcdefghi", 
				"abcdefghij", "abcdefghijk", "abcdefghijkl", 
				"abcdefghijklm", "abcdefghijklmn", "abcdefghijklmno", 
				"abcdefghijklmnop", "abcdefghijklmnopq", "abcdefghijklmnopqr", 
				"abcdefghijklmnopqrs", "abcdefghijklmnopqrst", "abcdefghijklmnopqrstu", 
				"abcdefghijklmnopqrstuv", "abcdefghijklmnopqrstuvw", "abcdefghijklmnopqrstuvwx", 
				"abcdefghijklmnopqrstuvwxy", "abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxyzA", 
				"abcdefghijklmnopqrstuvwxyzAB", "abcdefghijklmnopqrstuvwxyzABC", "abcdefghijklmnopqrstuvwxyzABCD", 
				"abcdefghijklmnopqrstuvwxyzABCDE", "abcdefghijklmnopqrstuvwxyzABCDEF", "abcdefghijklmnopqrstuvwxyzABCDEFG", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGH", "abcdefghijklmnopqrstuvwxyzABCDEFGHI", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJ", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJK", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKL", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMN", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNO", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQR", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRS", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRST", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUV", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVW", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWX", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"}
		,{
				"", 
				"f", "ff", "ffd", 
				"ffdf", "ffdfk", "ffdfkl", 
				"ffdfklf", "ffdfklfj", "ffdfklfjk", 
				"ffdfklfjkl", "ffdfklfjkls", "ffdfklfjklsf", 
				"ffdfklfjklsfj", "ffdfklfjklsfjl", "ffdfklfjklsfjlj", 
				"ffdfklfjklsfjljk", "ffdfklfjklsfjljkl", "ffdfklfjklsfjljkle", 
				"ffdfklfjklsfjljklej", "ffdfklfjklsfjljklejz", "ffdfklfjklsfjljklejzz", 
				"ffdfklfjklsfjljklejzzr", "ffdfklfjklsfjljklejzzri", "ffdfklfjklsfjljklejzzriz", 
				"ffdfklfjklsfjljklejzzrizo", "ffdfklfjklsfjljklejzzrizoj", "ffdfklfjklsfjljklejzzrizojn", 
				"ffdfklfjklsfjljklejzzrizojnj", "ffdfklfjklsfjljklejzzrizojnjn", "ffdfklfjklsfjljklejzzrizojnjnk", 
				"ffdfklfjklsfjljklejzzrizojnjnkn", "ffdfklfjklsfjljklejzzrizojnjnknj", "ffdfklfjklsfjljklejzzrizojnjnknjn", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnk", "ffdfklfjklsfjljklejzzrizojnjnknjnkj", "ffdfklfjklsfjljklejzzrizojnjnknjnkjq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqn", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqna", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaza", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazl", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxm", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzl", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzld", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzo", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzos", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzosz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzo", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
		},{
				"", 
				"a", "aa", "aaa", 
				"aaas", "aaask", "aaaskj", 
				"aaaskjn", "aaaskjnx", "aaaskjnxa", 
				"aaaskjnxad", "aaaskjnxadk", "aaaskjnxadkd", 
				"aaaskjnxadkdq", "aaaskjnxadkdqz", "aaaskjnxadkdqzn", 
				"aaaskjnxadkdqznd", "aaaskjnxadkdqzndl", "aaaskjnxadkdqzndlx", 
				"aaaskjnxadkdqzndlxd", "aaaskjnxadkdqzndlxdz", "aaaskjnxadkdqzndlxdzd", 
				"aaaskjnxadkdqzndlxdzdz", "aaaskjnxadkdqzndlxdzdze", "aaaskjnxadkdqzndlxdzdzex", 
				"aaaskjnxadkdqzndlxdzdzexd", "aaaskjnxadkdqzndlxdzdzexdd", "aaaskjnxadkdqzndlxdzdzexddd", 
				"aaaskjnxadkdqzndlxdzdzexddde", "aaaskjnxadkdqzndlxdzdzexddded", "aaaskjnxadkdqzndlxdzdzexdddedx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxf", "aaaskjnxadkdqzndlxdzdzexdddedxfq", "aaaskjnxadkdqzndlxdzdzexdddedxfqg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxe", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxege", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeger", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegerg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgre", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgreg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxz", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"		
		}};
		String[][] resFin= {
				{
					"", 
					"0", "90", "890", 
					"7890", "67890", "567890", 
					"4567890", "34567890", "234567890", 
					"1234567890", "Z1234567890", "YZ1234567890", 
					"XYZ1234567890", "WXYZ1234567890", "VWXYZ1234567890", 
					"UVWXYZ1234567890", "TUVWXYZ1234567890", "STUVWXYZ1234567890", 
					"RSTUVWXYZ1234567890", "QRSTUVWXYZ1234567890", "PQRSTUVWXYZ1234567890", 
					"OPQRSTUVWXYZ1234567890", "NOPQRSTUVWXYZ1234567890", "MNOPQRSTUVWXYZ1234567890", 
					"LMNOPQRSTUVWXYZ1234567890", "KLMNOPQRSTUVWXYZ1234567890", "JKLMNOPQRSTUVWXYZ1234567890", 
					"IJKLMNOPQRSTUVWXYZ1234567890", "HIJKLMNOPQRSTUVWXYZ1234567890", "GHIJKLMNOPQRSTUVWXYZ1234567890", 
					"FGHIJKLMNOPQRSTUVWXYZ1234567890", "EFGHIJKLMNOPQRSTUVWXYZ1234567890", "DEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"CDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "BCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"zABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "yzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "xyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"wxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "vwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "uvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"tuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "stuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "rstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"qrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "pqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"nopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "mnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "lmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"klmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"hijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "fghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"efghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "defghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "cdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"bcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
				}, {
					"", 
					"a", "oa", "zoa", 
					"zzoa", "dzzoa", "zdzzoa", 
					"dzdzzoa", "zdzdzzoa", "xzdzdzzoa", 
					"zxzdzdzzoa", "szxzdzdzzoa", "oszxzdzdzzoa", 
					"zoszxzdzdzzoa", "dzoszxzdzdzzoa", "ldzoszxzdzdzzoa", 
					"zldzoszxzdzdzzoa", "mzldzoszxzdzdzzoa", "xmzldzoszxzdzdzzoa", 
					"lxmzldzoszxzdzdzzoa", "zlxmzldzoszxzdzdzzoa", "azlxmzldzoszxzdzdzzoa", 
					"zazlxmzldzoszxzdzdzzoa", "azazlxmzldzoszxzdzdzzoa", "qazazlxmzldzoszxzdzdzzoa", 
					"aqazazlxmzldzoszxzdzdzzoa", "naqazazlxmzldzoszxzdzdzzoa", "qnaqazazlxmzldzoszxzdzdzzoa", 
					"jqnaqazazlxmzldzoszxzdzdzzoa", "kjqnaqazazlxmzldzoszxzdzdzzoa", "nkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnkjqnaqazazlxmzldzoszxzdzdzzoa", "knjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"nknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"izojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "rizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"zzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"lejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"sfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"klfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "dfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"fdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
				}, {
					"", 
					"h", "hh", "hhh", 
					"xhhh", "gxhhh", "zgxhhh", 
					"xzgxhhh", "rxzgxhhh", "grxzgxhhh", 
					"rgrxzgxhhh", "grgrxzgxhhh", "xgrgrxzgxhhh", 
					"gxgrgrxzgxhhh", "egxgrgrxzgxhhh", "regxgrgrxzgxhhh", 
					"gregxgrgrxzgxhhh", "rgregxgrgrxzgxhhh", "rrgregxgrgrxzgxhhh", 
					"grrgregxgrgrxzgxhhh", "rgrrgregxgrgrxzgxhhh", "ergrrgregxgrgrxzgxhhh", 
					"gergrrgregxgrgrxzgxhhh", "egergrrgregxgrgrxzgxhhh", "xegergrrgregxgrgrxzgxhhh", 
					"gxegergrrgregxgrgrxzgxhhh", "qgxegergrrgregxgrgrxzgxhhh", "xqgxegergrrgregxgrgrxzgxhhh", 
					"gxqgxegergrrgregxgrgrxzgxhhh", "qgxqgxegergrrgregxgrgrxzgxhhh", "gqgxqgxegergrrgregxgrgrxzgxhhh", 
					"qgqgxqgxegergrrgregxgrgrxzgxhhh", "fqgqgxqgxegergrrgregxgrgrxzgxhhh", "xfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"dxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "edxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"ddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"exdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "zexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"lxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "ndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "qzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "adkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"xadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "nxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "jnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "skjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "askjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"	
				}
		};
		System.out.println("\nTest de debutIte :");
		/*
		for (int i=0; i<=s3.length()+3; i++) {
			System.out.print("\""+Chaines.finRec(s3, i)+"\", ");
			if (i%3==0) {
				System.out.println();
			}
		}*/
		int k=0;
		int jeu=0;
		boolean ok=true;
		while (jeu<resDeb.length && ok) {
			
		k=0;
		while (k<resDeb[jeu].length && ok) {
			ok = (Chaines.debutIte(jeux[jeu], k).equals(resDeb[jeu][k]));
			if (!ok) {
				System.out.println("   Aie... debutIte(\""+jeux[jeu]+"\", "+k+") retourne \""+Chaines.debutIte(jeux[jeu], k)+"\" au lieu de \""+resDeb[jeu][k]+"\"");
				note=0;
			}
			k++;
		}
		jeu++;
		}
		if (note>0) {
			String met = methode(sansCommentaires("src"+File.separator+"Chaines.java"),"debutIte").substring(2);
			//System.out.println(met);
			if (met.contains("debutIte")||met.contains("debutRec")) {
				System.out.println("   Aie... votre implementation de debutIte NE doit PAS etre RECURSIVE");
				note=0;
			}
		} 
		
		
		if (note==100) {		
			System.out.println("  Ok. Votre code passe le test");
		}
		return note;
	}
	
	
	
	

	public static int testFinIte() {
		int note=100;
		String[] jeux = {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
		"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa",
		"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"};

		String[][] resDeb= {{"", 
				"a", "ab", "abc", 
				"abcd", "abcde", "abcdef", 
				"abcdefg", "abcdefgh", "abcdefghi", 
				"abcdefghij", "abcdefghijk", "abcdefghijkl", 
				"abcdefghijklm", "abcdefghijklmn", "abcdefghijklmno", 
				"abcdefghijklmnop", "abcdefghijklmnopq", "abcdefghijklmnopqr", 
				"abcdefghijklmnopqrs", "abcdefghijklmnopqrst", "abcdefghijklmnopqrstu", 
				"abcdefghijklmnopqrstuv", "abcdefghijklmnopqrstuvw", "abcdefghijklmnopqrstuvwx", 
				"abcdefghijklmnopqrstuvwxy", "abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxyzA", 
				"abcdefghijklmnopqrstuvwxyzAB", "abcdefghijklmnopqrstuvwxyzABC", "abcdefghijklmnopqrstuvwxyzABCD", 
				"abcdefghijklmnopqrstuvwxyzABCDE", "abcdefghijklmnopqrstuvwxyzABCDEF", "abcdefghijklmnopqrstuvwxyzABCDEFG", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGH", "abcdefghijklmnopqrstuvwxyzABCDEFGHI", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJ", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJK", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKL", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMN", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNO", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQR", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRS", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRST", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUV", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVW", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWX", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
				"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"}
		,{
				"", 
				"f", "ff", "ffd", 
				"ffdf", "ffdfk", "ffdfkl", 
				"ffdfklf", "ffdfklfj", "ffdfklfjk", 
				"ffdfklfjkl", "ffdfklfjkls", "ffdfklfjklsf", 
				"ffdfklfjklsfj", "ffdfklfjklsfjl", "ffdfklfjklsfjlj", 
				"ffdfklfjklsfjljk", "ffdfklfjklsfjljkl", "ffdfklfjklsfjljkle", 
				"ffdfklfjklsfjljklej", "ffdfklfjklsfjljklejz", "ffdfklfjklsfjljklejzz", 
				"ffdfklfjklsfjljklejzzr", "ffdfklfjklsfjljklejzzri", "ffdfklfjklsfjljklejzzriz", 
				"ffdfklfjklsfjljklejzzrizo", "ffdfklfjklsfjljklejzzrizoj", "ffdfklfjklsfjljklejzzrizojn", 
				"ffdfklfjklsfjljklejzzrizojnj", "ffdfklfjklsfjljklejzzrizojnjn", "ffdfklfjklsfjljklejzzrizojnjnk", 
				"ffdfklfjklsfjljklejzzrizojnjnkn", "ffdfklfjklsfjljklejzzrizojnjnknj", "ffdfklfjklsfjljklejzzrizojnjnknjn", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnk", "ffdfklfjklsfjljklejzzrizojnjnknjnkj", "ffdfklfjklsfjljklejzzrizojnjnknjnkjq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqn", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqna", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaq", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqaza", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazaz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazl", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxm", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzl", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzld", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzo", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzos", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzosz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszx", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzd", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdz", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzz", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzo", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
				"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
		},{
				"", 
				"a", "aa", "aaa", 
				"aaas", "aaask", "aaaskj", 
				"aaaskjn", "aaaskjnx", "aaaskjnxa", 
				"aaaskjnxad", "aaaskjnxadk", "aaaskjnxadkd", 
				"aaaskjnxadkdq", "aaaskjnxadkdqz", "aaaskjnxadkdqzn", 
				"aaaskjnxadkdqznd", "aaaskjnxadkdqzndl", "aaaskjnxadkdqzndlx", 
				"aaaskjnxadkdqzndlxd", "aaaskjnxadkdqzndlxdz", "aaaskjnxadkdqzndlxdzd", 
				"aaaskjnxadkdqzndlxdzdz", "aaaskjnxadkdqzndlxdzdze", "aaaskjnxadkdqzndlxdzdzex", 
				"aaaskjnxadkdqzndlxdzdzexd", "aaaskjnxadkdqzndlxdzdzexdd", "aaaskjnxadkdqzndlxdzdzexddd", 
				"aaaskjnxadkdqzndlxdzdzexddde", "aaaskjnxadkdqzndlxdzdzexddded", "aaaskjnxadkdqzndlxdzdzexdddedx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxf", "aaaskjnxadkdqzndlxdzdzexdddedxfq", "aaaskjnxadkdqzndlxdzdzexdddedxfqg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxq", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxe", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxege", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxeger", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegerg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgr", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgre", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgreg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregx", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrg", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgr", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxz", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzg", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgx", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
				"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"		
		}};
		String[][] resFin= {
				{
					"", 
					"0", "90", "890", 
					"7890", "67890", "567890", 
					"4567890", "34567890", "234567890", 
					"1234567890", "Z1234567890", "YZ1234567890", 
					"XYZ1234567890", "WXYZ1234567890", "VWXYZ1234567890", 
					"UVWXYZ1234567890", "TUVWXYZ1234567890", "STUVWXYZ1234567890", 
					"RSTUVWXYZ1234567890", "QRSTUVWXYZ1234567890", "PQRSTUVWXYZ1234567890", 
					"OPQRSTUVWXYZ1234567890", "NOPQRSTUVWXYZ1234567890", "MNOPQRSTUVWXYZ1234567890", 
					"LMNOPQRSTUVWXYZ1234567890", "KLMNOPQRSTUVWXYZ1234567890", "JKLMNOPQRSTUVWXYZ1234567890", 
					"IJKLMNOPQRSTUVWXYZ1234567890", "HIJKLMNOPQRSTUVWXYZ1234567890", "GHIJKLMNOPQRSTUVWXYZ1234567890", 
					"FGHIJKLMNOPQRSTUVWXYZ1234567890", "EFGHIJKLMNOPQRSTUVWXYZ1234567890", "DEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"CDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "BCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"zABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "yzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "xyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"wxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "vwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "uvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"tuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "stuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "rstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"qrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "pqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"nopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "mnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "lmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"klmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"hijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "ghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "fghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"efghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "defghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "cdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"bcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 
					"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
				}, {
					"", 
					"a", "oa", "zoa", 
					"zzoa", "dzzoa", "zdzzoa", 
					"dzdzzoa", "zdzdzzoa", "xzdzdzzoa", 
					"zxzdzdzzoa", "szxzdzdzzoa", "oszxzdzdzzoa", 
					"zoszxzdzdzzoa", "dzoszxzdzdzzoa", "ldzoszxzdzdzzoa", 
					"zldzoszxzdzdzzoa", "mzldzoszxzdzdzzoa", "xmzldzoszxzdzdzzoa", 
					"lxmzldzoszxzdzdzzoa", "zlxmzldzoszxzdzdzzoa", "azlxmzldzoszxzdzdzzoa", 
					"zazlxmzldzoszxzdzdzzoa", "azazlxmzldzoszxzdzdzzoa", "qazazlxmzldzoszxzdzdzzoa", 
					"aqazazlxmzldzoszxzdzdzzoa", "naqazazlxmzldzoszxzdzdzzoa", "qnaqazazlxmzldzoszxzdzdzzoa", 
					"jqnaqazazlxmzldzoszxzdzdzzoa", "kjqnaqazazlxmzldzoszxzdzdzzoa", "nkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnkjqnaqazazlxmzldzoszxzdzdzzoa", "knjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"nknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "njnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"izojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "rizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "zrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"zzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"lejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "jljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"sfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "klsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"jklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "lfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"klfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "fklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "dfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"fdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", 
					"ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa", "ffdfklfjklsfjljklejzzrizojnjnknjnkjqnaqazazlxmzldzoszxzdzdzzoa"
				}, {
					"", 
					"h", "hh", "hhh", 
					"xhhh", "gxhhh", "zgxhhh", 
					"xzgxhhh", "rxzgxhhh", "grxzgxhhh", 
					"rgrxzgxhhh", "grgrxzgxhhh", "xgrgrxzgxhhh", 
					"gxgrgrxzgxhhh", "egxgrgrxzgxhhh", "regxgrgrxzgxhhh", 
					"gregxgrgrxzgxhhh", "rgregxgrgrxzgxhhh", "rrgregxgrgrxzgxhhh", 
					"grrgregxgrgrxzgxhhh", "rgrrgregxgrgrxzgxhhh", "ergrrgregxgrgrxzgxhhh", 
					"gergrrgregxgrgrxzgxhhh", "egergrrgregxgrgrxzgxhhh", "xegergrrgregxgrgrxzgxhhh", 
					"gxegergrrgregxgrgrxzgxhhh", "qgxegergrrgregxgrgrxzgxhhh", "xqgxegergrrgregxgrgrxzgxhhh", 
					"gxqgxegergrrgregxgrgrxzgxhhh", "qgxqgxegergrrgregxgrgrxzgxhhh", "gqgxqgxegergrrgregxgrgrxzgxhhh", 
					"qgqgxqgxegergrrgregxgrgrxzgxhhh", "fqgqgxqgxegergrrgregxgrgrxzgxhhh", "xfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"dxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "edxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"ddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"exdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "zexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "xdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"lxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "ndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"zndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "qzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "dkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "adkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"xadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "nxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "jnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"kjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "skjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "askjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", 
					"aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh", "aaaskjnxadkdqzndlxdzdzexdddedxfqgqgxqgxegergrrgregxgrgrxzgxhhh"	
				}
		};
		System.out.println("\nTest de finIte :");
		/*
		for (int i=0; i<=s3.length()+3; i++) {
			System.out.print("\""+Chaines.finRec(s3, i)+"\", ");
			if (i%3==0) {
				System.out.println();
			}
		}*/
		int k=0;
		int jeu=0;
		boolean ok=true;
		while (jeu<resFin.length && ok) {
			
		k=0;
		while (k<resFin[jeu].length && ok) {
			ok = (Chaines.finIte(jeux[jeu], k).equals(resFin[jeu][k]));
			if (!ok) {
				System.out.println("   Aie... finIte(\""+jeux[jeu]+"\", "+k+") retourne \""+Chaines.finIte(jeux[jeu], k)+"\" au lieu de \""+resFin[jeu][k]+"\"");
				note=0;
			}
			k++;
		}
		jeu++;
		}
		if (note>0) {
			String met = methode(sansCommentaires("src"+File.separator+"Chaines.java"),"finIte").substring(2);
			//System.out.println(met);
			if (met.contains("finIte")||met.contains("finRec")) {
				System.out.println("   Aie... votre implementation de finIte NE doit PAS etre RECURSIVE");
				note=0;
			}
		} 
		
		
		if (note==100) {		
			System.out.println("  Ok. Votre code passe le test");
		}
		return note;
	}
	
	

	public static void main(String[] args) {
		int ntestIdentiques = 0;
		int ntestDebutIte = 0;
		int ntestFinRec =0;
		int ntestFinIte=0;
		int ntestSupprimer=0;

		int DeclarationNEtConst=0;
		try {
			ntestIdentiques = testDebutRec();//testDeclarationNatEtConst();//FEDeclaration   testFEDeclarationEtConstructeur();
			System.out.println("--> "+ntestIdentiques+"/100");
		} catch(Throwable e) {
			afficheThrowable(e, "testIdentiques");
		}
		finally {

			try {
				ntestDebutIte = testDebutIte();//testN0ConstructeursSans();// FEConstructeurSans  testFEConstructeursSans();
				System.out.println("--> "+ntestDebutIte+"/100");
			} catch(Throwable e) {
				afficheThrowable(e, "testDebutIte");
			}
			finally {
				try {
					ntestFinRec = testFinRec();
					System.out.println("--> "+ntestFinRec+"/100");

				} catch(Throwable e) {
					afficheThrowable(e, "testFinRec");
				}
				finally {
					try {
						ntestFinIte = testFinIte();
						System.out.println("--> "+ntestFinIte+"/100");
					} catch(Throwable e) {
						afficheThrowable(e, "testFinIte");
					}
					finally {
/*
						try {
							ntestSupprimer = testSupprimer();
							System.out.println("--> "+ntestSupprimer+"/100");
						} catch(Throwable e) {
							afficheThrowable(e, "testSupprimer");
						}
						finally {
						

						}*/
					}
				}
			}
		}
	}

	public static String toString(int[] t) {
		String res = "{";
		for (int i=0; i<t.length-1; i++) {
			res += t[i]+", ";
		}
		if (t.length>0) {
			res+=t[t.length-1];
		}
		return res+"}";
	}

	public static boolean equals(int[] t1, int[]t2, int pos) {
		return  (pos==0) ? true : t1[pos-1]==t2[pos-1] && equals(t1, t2, pos-1);
	}
	public static boolean equals(int[]t1, int[]t2) {
		return  t1!=null && t2!=null && t1.length==t2.length && equals(t1, t2, t1.length);
	}
	public void setClipboardContents(String s) {
		StringSelection ss = new StringSelection(s);
		Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
		cb.setContents(ss, this);
	}
	public void lostOwnership(Clipboard arg0, Transferable arg1) {
		System.out.println("<<< copie dans le presse-papier >>>");
	}

	public static void setClipboardContentsStatic(String s) {
		TestsChaines t = new TestsChaines();
		t.setClipboardContents(s);
	}
}