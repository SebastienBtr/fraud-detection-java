
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	
	public static int nbVoyelles (String s, int i) {
		/*if (i==1) {
			if (s.charAt(i-1).equals("A") || s.charAt(i-1).equals("E") || s.charAt(i-1).equal("I") || s.charAt(i-1).equals("O") || s.charAt(i-1).equals("U") || s.charAt(i-1).equals("Y")) {
				return 1;
			} else {
				return 0;
			}
		} else {
			if (s.charAt(i-1).equals("A") || s.charAt(i-1).equals("E") || s.charAt(i-1).equal("I") || s.charAt(i-1).equals("O") || s.charAt(i-1).equals("U") || s.charAt(i-1).equals("Y")) {
				return nbVoyelles(s,i-1)+1;
			} else {
				return nbVoyelles(s,i-1);
			}
		}
		*/
		return 0;
	}

	public static int nbVoyelles(String s) {
		return nbVoyelles(s,s.length());
	}	
}
