public class NombresTriangulaires {

	/**
	 * @param n, un entier positif (n>=0)
	 * @return Retourne le nombre triangulaire Tn
	 * Exemple : triangulaire(6) retourne 21.
	 * 
	 * ATTENTION : VOTRE CODE DOIT ETRE RECURSIF !!!
	 * 
	 */
	public static int triangulaire(int n){
		int rep=0;
		if (n>0) {
			
			rep = n + triangulaire(n-1);
		}
		
		return rep;	
	}
}
