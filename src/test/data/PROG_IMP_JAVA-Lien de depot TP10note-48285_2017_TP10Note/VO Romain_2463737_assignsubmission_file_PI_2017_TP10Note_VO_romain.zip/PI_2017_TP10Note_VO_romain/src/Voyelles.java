
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		int rep =0;
		if (s.length() > 0) {
			if (s.charAt(s.length()-1)==('A') || s.charAt(s.length()-1)==('E') || s.charAt(s.length()-1)== ('I') || s.charAt(s.length()-1)==('O') || s.charAt(s.length()-1)==('U') || s.charAt(s.length()-1)==('Y')) {
				rep=1+nbVoyelles(s.substring(0,s.length()-1));
			} else {
				rep=0+nbVoyelles(s.substring(0,s.length()-1));
			}
		}
		return rep; 
	}	
}
