public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return a;
		}
		else {
			int min=b;
			int max=a;
			if (a<b) {
				min =a;
				max=b;
			}
			return pgcdRec(min,max-min);
		}
	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) {
		int min=a;
		int max=b;
		if (a>b) {
			min=b;
			max=a;
		}
		if (a==b) {
			return a;
		}
		else {
			
			while (a>1 && b>1) {
				a=min;
				b=max-min;
			}
		}
		return max;
	}
}
