public class Index {

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus grand i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int lastIndexOf(int[] t, int pos, int valeur) {
		if (pos == 0) {
			return -1;
			
			}
		
		else {
			if (t[pos-1]!=valeur) {
			return lastIndexOf(t, pos -1, valeur);
			
			}
			else {
				return(pos-1);
			}
			
		}
		
	}

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus petit i de [0, pos[ tel que t[i]==valeur
	 * 
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int firstIndexOf(int[] t, int pos, int valeur) {
		if (pos == 0) {
			return -1;
			
			}
		
		else {
			int i = 0;
			if (t[0]!=valeur){
				i++;
				int[] t2 = new int[t.length-1];
				for (int k=1;k<t.length;k++) {
					t2[k-1]=t[k];
				}
				return lastIndexOf(t2, pos -1, valeur);
			
			}
			else {
				return(pos-1);
			}
			
		}
	}
}
