
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles_aux(String s, int compteur) {
		if (s.length()==0) {
			return compteur;
		}
		//else if ((s.charAt(0).equals("A")) || (s.charAt(0).equals("E")) || (s.charAt(0).equals("I")) || (s.charAt(0).equals("O")) || (s.charAt(0).equals == U) || (s.charAt(0) == Y)) {
		//return nbVoyelles_aux(s.substring(1, s.length()),compteur +1);
		//}
		else {
			return nbVoyelles_aux(s.substring(1, s.length()),compteur);
		}
	}
	public static int nbVoyelles(String s) {
		return nbVoyelles_aux(s,0);
	}	
}
