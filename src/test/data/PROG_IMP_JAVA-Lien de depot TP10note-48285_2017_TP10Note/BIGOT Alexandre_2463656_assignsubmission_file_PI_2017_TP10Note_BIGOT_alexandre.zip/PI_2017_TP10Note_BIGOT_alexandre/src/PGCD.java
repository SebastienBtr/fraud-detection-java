public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b) {
			return(a);
		}else {
		return pgcdRec(Math.min(a, b),Math.max(a, b)-Math.min(a, b));// A VOUS DE COMPLETER	
	}}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		int n=Math.max(a, b);
		int pgcd=0;
		for(int i=1;i<=n;i++) {
			if (a%i==0 && b%i==0) {
				pgcd=i;
			}
		}
		return pgcd;// A VOUS DE COMPLETER	
	}
}
