
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length()==0) {
			return(1);
		}
		else {
			System.out.println(s.substring(s.length()-1, s.length()));
			if (s.substring(s.length()-1, s.length())=="A" || s.substring(s.length()-1, s.length())=="E" || s.substring(s.length()-1, s.length())=="I" || s.substring(s.length()-1, s.length())=="O" || s.substring(s.length()-1, s.length())=="U" || s.substring(s.length()-1, s.length())=="Y") {
				return( nbVoyelles(s.substring(0,s.length()-1)) +1 );
			}
			else {
				return(nbVoyelles(s.substring(0,s.length()-1)));
			}
		}
		// A VOUS DE COMPLETER
	}	
}
