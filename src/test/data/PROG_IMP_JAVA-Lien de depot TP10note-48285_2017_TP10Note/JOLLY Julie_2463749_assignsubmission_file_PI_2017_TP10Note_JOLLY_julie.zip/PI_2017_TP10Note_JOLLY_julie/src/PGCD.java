public class PGCD {
	/**
	 * VERSION RECURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdRec(int a, int b) { 
		if (a==b){
			return a;
		} else {
			return pgcdRec(Math.min(a, b), Math.max(a, b)-Math.min(a, b));
		}

	}
	/**
	 * VERSION ITERATIVE / NON RCURSIVE !!!
	 * @param a, a>=0
	 * @param b, b>=0
	 * @return Retourne le pgcd de a et de b
	 */
	public static int pgcdIte(int a, int b) { 
		return -1;// A VOUS DE COMPLETER	
	}
}
