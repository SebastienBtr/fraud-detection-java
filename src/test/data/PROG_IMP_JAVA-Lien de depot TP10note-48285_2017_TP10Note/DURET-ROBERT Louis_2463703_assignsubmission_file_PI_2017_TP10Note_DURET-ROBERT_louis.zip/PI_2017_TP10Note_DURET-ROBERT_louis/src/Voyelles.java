
public class Voyelles {

	/**
	 *
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length() == 0) {
			return 0;
		} else {
			int temp = 0;
			char t_char = s.charAt(0);
			if (t_char=='A' || t_char=='E' || t_char=='I' || t_char=='O' || t_char=='U' || t_char=='Y') {
				temp = 1;
			}
			String tronque = s.substring(1, s.length());
			return temp + nbVoyelles(tronque);
		}
	}
}
