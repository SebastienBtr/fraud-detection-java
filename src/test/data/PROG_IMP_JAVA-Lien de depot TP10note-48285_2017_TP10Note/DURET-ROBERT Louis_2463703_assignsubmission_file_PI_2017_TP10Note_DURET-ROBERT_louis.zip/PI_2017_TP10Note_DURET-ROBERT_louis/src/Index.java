public class Index {

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus grand i de [0, pos[ tel que t[i]==valeur
	 *
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int lastIndexOf(int[] t, int pos, int valeur) {
		if (pos == 0) {
			return -1;
		} else if (t[pos-1] == valeur) {
			return (pos-1);
		} else {
			return lastIndexOf(t, pos-1, valeur);
		}
	}

	/**
	 * @param t, un tableau d'au moins pos entiers (t.length>=pos)
	 * @param pos, une entier positif (pos>=0)
	 * @param valeur
	 * @return Si aucune des pos premieres valeurs de t ne vaut valeur, retourne -1.
	 * Sinon, retourne le plus petit i de [0, pos[ tel que t[i]==valeur
	 *
	 * ATTENTION : Votre code doit etre RECURSIF
	 */
	public static int firstIndexOf(int[] t, int pos, int valeur) {
		// System.out.println(pos);
		// if (pos == 0 || t.length == 0) {
		// 	System.out.println("return -pos-1;");
		// 	return -pos-1;
		// } else if (t[0] == valeur) {
		// 	System.out.println("return 1;");
		// 	return 1;
		// } else {
		// 	int[] temp = new int[t.length-1];
		// 	for (int iii = 1; iii<t.length; iii++) {
		// 		temp[iii-1] = t[iii];
		// 	}
		// 	System.out.println("increment");
		// 	return 1 + firstIndexOf(temp, pos, valeur);
		// }
		return 0; // possible ?
	}
}
