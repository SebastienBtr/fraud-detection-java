
public class Voyelles {

	/**
	 * 
	 * @param s, une chaine de caracteres en majuscules non accentuees. s!=null
	 * @return Retourne le nombre de voyelles que comporte la chaine s.
	 * Exemples : nbVoyelles("BON") retourne 1
	 *            nbVoyelles("BONJOUR") retourne 3
	 *            nbVoyelles("CE CRAYON EST TAILLE") retourne 8
	 */
	public static int nbVoyelles(String s) {
		if (s.length() == 1) {
			if (s == "A" || s == "E" || s == "I" || s == "O" || s == "U" || s == "Y") {
				return 1 ;
			}
			else {
				return 0 ;
			}
		}
		else {
			String t = "" + s.charAt(s.length() - 1) ;
			if (t == "A" || t == "E" || t == "I" || t == "O" || t == "U" || t == "Y") {
				return nbVoyelles(s.substring(0,  s.length() - 1)) + 1 ;
			}
			else {
				return nbVoyelles(s.substring(0,  s.length() - 1)) ;
			}
		}
	}	
}
